"use strict";exports.id=72,exports.ids=[72],exports.modules={586:(e,t,a)=>{a.d(t,{A:()=>s});let s=(0,a(2614).A)("Filter",[["polygon",{points:"22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3",key:"1yg77f"}]])},916:(e,t,a)=>{a.d(t,{A:()=>s});let s=(0,a(2614).A)("Star",[["path",{d:"M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z",key:"r04s7s"}]])},1936:(e,t,a)=>{a.d(t,{A:()=>s});let s=(0,a(2614).A)("Search",[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]])},4008:(e,t,a)=>{a.d(t,{A:()=>r,t:()=>s});let s=[{id:"membership",name:"Membership",description:"Updates and benefits for our member community"},{id:"bespoke-wigs",name:"Bespoke Wigs & Toppers",description:"Custom-made hairpiece insights and stories"},{id:"ready-made",name:"Ready-Made Collection",description:"Our curated selection of premium wigs and toppers"},{id:"education",name:"Education & Training",description:"Professional courses and learning resources"},{id:"care-tips",name:"Care & Maintenance",description:"Expert tips for maintaining your hairpieces"},{id:"styling",name:"Styling Guide",description:"Creative styling ideas and techniques"}],r=[{id:"1",title:"The Ultimate Guide to Measuring Your Head for a Perfect Wig Fit",excerpt:"Learn the professional techniques our experts use to ensure your custom wig fits perfectly every time.",content:`Getting the perfect fit for your wig starts with accurate measurements. In this comprehensive guide, we'll walk you through the exact process our master craftspeople use at Berenice London.

## Why Accurate Measurements Matter

A properly fitted wig not only looks more natural but also feels more comfortable and secure. Poor measurements can lead to slipping, discomfort, or an unnatural appearance.

## Essential Tools You'll Need

- A flexible measuring tape
- A mirror
- A pen and paper
- A friend to help (optional but recommended)

## Step-by-Step Measurement Process

### 1. Circumference Measurement
Place the measuring tape around your head, about 1/8 inch above your ears and across your forehead. This gives you the overall head circumference.

### 2. Front to Back Measurement
Measure from your natural hairline at the forehead to the nape of your neck, going over the crown of your head.

### 3. Ear to Ear Measurement
Measure from the top of one ear, over the crown, to the top of the other ear.

### 4. Temple to Temple
Measure across your forehead from temple to temple, about 1 inch above your eyebrows.

## Tips for Accuracy

- Take measurements when your hair is flat against your head
- Don't pull the tape too tight or too loose
- Take each measurement twice to ensure accuracy
- Have someone help you for the most precise results

## What to Do With Your Measurements

Once you have all your measurements, our team will use these to create your custom pattern. We'll also discuss your lifestyle, styling preferences, and any specific needs you might have.

Remember, at Berenice London, we're here to guide you through every step of the process. Book a consultation with our experts to ensure your measurements are perfect and discuss your custom wig options.`,category:"education",author:"Sarah Mitchell",publishDate:"2024-01-15",readTime:5,tags:["measurements","fitting","custom-wigs","how-to"],featured:!0,imageUrl:"https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=800&h=400&fit=crop"},{id:"2",title:"Washing Your Hairpiece: A Complete Care Guide",excerpt:"Proper washing techniques to maintain the beauty and longevity of your premium hairpiece.",content:`Your hairpiece is an investment in your confidence and appearance. Proper care, especially washing, is essential to maintain its beauty and extend its lifespan.

## How Often to Wash

The frequency of washing depends on several factors:
- How often you wear your hairpiece
- Your lifestyle and activities
- Environmental factors
- Hair type (synthetic vs. human hair)

Generally, wash your hairpiece every 6-8 wears for human hair pieces, and every 10-12 wears for synthetic ones.

## What You'll Need

- Specialized wig shampoo (never use regular hair shampoo)
- Wig conditioner
- A wide-tooth comb
- A wig stand or mannequin head
- Clean towels
- Cool water

## Step-by-Step Washing Process

### Preparation
1. Gently brush your hairpiece to remove tangles
2. Fill a basin with cool water
3. Add a small amount of wig shampoo

### Washing
1. Immerse the hairpiece in the water
2. Gently swish for 2-3 minutes
3. Don't rub or scrub the hair
4. Rinse thoroughly with cool water

### Conditioning
1. Apply wig conditioner from mid-length to ends
2. Leave for 2-3 minutes
3. Rinse thoroughly

### Drying
1. Gently squeeze out excess water (don't wring)
2. Pat dry with a clean towel
3. Place on a wig stand to air dry
4. Never use heat unless the piece is specifically designed for it

## Pro Tips

- Always wash in cool water to prevent damage
- Use products specifically designed for wigs
- Be gentle throughout the process
- Store properly when not in use

Following these steps will help ensure your Berenice London hairpiece maintains its premium quality and appearance for years to come.`,category:"care-tips",author:"Emma Thompson",publishDate:"2024-01-10",readTime:4,tags:["hair-care","washing","maintenance","hairpiece"],featured:!0,imageUrl:"https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=800&h=400&fit=crop"},{id:"3",title:"New Premium Membership Benefits: What You Need to Know",excerpt:"Discover the exciting new benefits we've added to our Premium and Elite membership tiers.",content:`We're thrilled to announce exciting new benefits for our Premium and Elite members, effective immediately. These enhancements reflect our commitment to providing exceptional value and service to our community.

## New Premium Membership Benefits

### Monthly Styling Consultations
Premium members now receive monthly virtual styling consultations with our expert team. Perfect for seasonal updates or special occasion styling.

### Exclusive Product Access
Get early access to new arrivals and limited-edition pieces before they're available to the general public.

### Enhanced Discount Structure
- 15% off all services (increased from 10%)
- 20% off ready-made collection
- Free shipping on all orders

## Elite Membership Enhancements

### Personal Stylist Assignment
Each Elite member now gets a dedicated personal stylist for ongoing support and customized recommendations.

### Quarterly In-Person Sessions
Enjoy quarterly in-person styling and maintenance sessions at our London studio.

### VIP Event Access
Exclusive invitations to styling workshops, fashion shows, and member-only events.

## How to Upgrade

Current Basic members can upgrade to Premium or Elite at any time through their member dashboard. Contact our team for personalized upgrade recommendations based on your needs.

## Coming Soon

We're also working on:
- Mobile app for easier booking and communication
- Virtual reality wig try-on technology
- Expanded educational content library

Thank you for being part of the Berenice London community. Your membership makes all these improvements possible.`,category:"membership",author:"Berenice London Team",publishDate:"2024-01-08",readTime:3,tags:["membership","benefits","premium","elite"],featured:!1},{id:"4",title:"The Art of Bespoke Wig Creation: Behind the Scenes",excerpt:"Take a journey into our workshop and discover the meticulous craftsmanship behind every custom piece.",content:`Creating a bespoke wig is both an art and a science. Each piece that leaves our London workshop represents hundreds of hours of skilled craftsmanship and attention to detail.

## The Design Process

Every bespoke piece begins with a comprehensive consultation. We discuss:
- Your lifestyle and daily routine
- Color preferences and skin tone
- Desired length and style
- Specific requirements or concerns

## Hair Selection

We source only the finest materials:
- Premium European hair for the most natural look
- Ethically sourced materials
- Multiple color matching for perfect blends
- Quality testing for durability and appearance

## The Crafting Process

### Foundation Creation
The wig cap is hand-crafted to your exact measurements, ensuring a perfect fit that's both comfortable and secure.

### Hair Insertion
Each hair is individually hand-tied using traditional techniques passed down through generations of master craftspeople.

### Styling and Finishing
The final styling brings your vision to life, with attention to natural growth patterns and movement.

## Quality Assurance

Before delivery, every piece undergoes rigorous quality checks:
- Fit verification
- Color accuracy
- Movement and naturalness
- Durability testing

## The Result

The result is a truly unique piece that not only meets but exceeds your expectations. A bespoke wig from Berenice London isn't just a hairpiece—it's a transformation that restores confidence and enhances your natural beauty.

Ready to begin your bespoke journey? Book a consultation with our master craftspeople today.`,category:"bespoke-wigs",author:"Master Craftsman James Wilson",publishDate:"2024-01-05",readTime:6,tags:["bespoke","craftsmanship","custom-wigs","process"],featured:!0,imageUrl:"https://images.unsplash.com/photo-1562322140-8baeececf3df?w=800&h=400&fit=crop"},{id:"5",title:"Spring 2024 Ready-Made Collection Preview",excerpt:"Get an exclusive first look at our stunning new ready-made pieces for the upcoming season.",content:`Spring brings new beginnings, and our Spring 2024 Ready-Made Collection embodies fresh sophistication and effortless elegance.

## Collection Highlights

### Natural Textures
This season emphasizes natural movement and texture, with pieces that complement rather than mask your natural beauty.

### Color Palette
- Warm honey blondes
- Rich chocolate browns
- Sophisticated salt-and-pepper grays
- Bold copper reds for the adventurous

### Trending Styles

#### The "London Bob"
A chic, shoulder-length cut with subtle layers that works for any occasion.

#### "Garden Party Waves"
Romantic, flowing waves perfect for spring and summer events.

#### "Executive Elegance"
Professional styles that command respect in any boardroom.

## Technical Innovations

### Improved Cap Construction
Our new cap design offers:
- Better breathability for warmer weather
- Enhanced comfort for all-day wear
- More secure fit with adjustable sizing

### Advanced Hair Processing
New treatment methods ensure:
- Longer-lasting color
- Improved texture retention
- Enhanced shine and movement

## Availability

The collection launches February 15th, with Premium and Elite members getting early access starting February 1st.

Each piece comes with:
- Professional styling guide
- Care instruction kit
- 6-month warranty
- Complimentary initial styling session

Visit our showroom or book a virtual consultation to see these beautiful pieces and find your perfect match for spring.`,category:"ready-made",author:"Design Team Lead Maria Rodriguez",publishDate:"2024-01-03",readTime:4,tags:["spring-2024","ready-made","collection","new-arrivals"],featured:!1,imageUrl:"https://images.unsplash.com/photo-1594736797933-d0e501ba2fe0?w=800&h=400&fit=crop"},{id:"6",title:"5 Essential Styling Tools Every Wig Owner Should Have",excerpt:"Build your styling toolkit with these professional-grade tools recommended by our expert stylists.",content:`The right tools make all the difference in maintaining and styling your wig. Here are the five essential items every wig owner should have in their toolkit.

## 1. Wide-Tooth Comb

### Why You Need It
A wide-tooth comb is gentle on wig fibers and prevents unnecessary tension that can cause shedding or damage.

### How to Use
- Always start combing from the ends
- Work your way up to the roots gradually
- Use gentle, downward motions

### Our Recommendation
Look for combs made from seamless materials to prevent snagging.

## 2. Wig Brush with Ball-Tipped Bristles

### Benefits
- Reduces static and flyaways
- Distributes natural oils evenly
- Gentle on both synthetic and human hair

### Best Practices
- Brush when the wig is dry
- Use long, smooth strokes
- Clean your brush regularly

## 3. Wig Stand or Mannequin Head

### Essential for
- Proper storage between wears
- Styling and maintenance
- Air drying after washing

### Storage Tips
- Choose a stand that matches your head size
- Store in a cool, dry place
- Cover with a silk scarf to prevent dust

## 4. Heat Protectant Spray

### When to Use
Before any heat styling on human hair wigs (never use heat on synthetic unless specifically designed for it).

### Protection Benefits
- Prevents heat damage
- Maintains hair integrity
- Extends wig lifespan

## 5. Specialized Wig Shampoo and Conditioner

### Why Regular Products Don't Work
Regular hair products can:
- Strip color from wig fibers
- Build up on the cap
- Reduce the wig's lifespan

### Choosing the Right Products
- Look for sulfate-free formulas
- Choose products designed for your wig type
- Consider professional-grade options

## Bonus Tool: Silk Scarf

### Multiple Uses
- Sleeping protection
- Storage covering
- Gentle drying aid

## Investment in Longevity

Quality tools are an investment in your wig's longevity and appearance. At Berenice London, we offer a complete styling toolkit designed specifically for our pieces.

Ready to upgrade your wig care routine? Contact our team for personalized tool recommendations based on your specific needs and wig type.`,category:"styling",author:"Senior Stylist Rachel Green",publishDate:"2023-12-28",readTime:5,tags:["styling-tools","wig-care","maintenance","professional-tips"],featured:!1}]},7034:(e,t,a)=>{a.d(t,{A:()=>s});let s=(0,a(2614).A)("BookOpen",[["path",{d:"M12 7v14",key:"1akyts"}],["path",{d:"M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z",key:"ruj8y"}]])},9072:(e,t,a)=>{a.d(t,{z:()=>v});var s=a(687),r=a(3210),i=a(5814),o=a.n(i),n=a(4493),l=a(9523),c=a(9667),u=a(6834),d=a(5079),h=a(4008),m=a(1936),p=a(586),g=a(916),y=a(6622),f=a(5036),w=a(8595),b=a(7034),x=a(8760);function v({showFeatured:e=!1,category:t,limit:a}){let[i,v]=(0,r.useState)(""),[j,k]=(0,r.useState)(t||"all"),[N,T]=(0,r.useState)("date"),A=(0,r.useMemo)(()=>{let t=h.A;if(e&&(t=t.filter(e=>e.featured)),"all"!==j&&(t=t.filter(e=>e.category===j)),i){let e=i.toLowerCase();t=t.filter(t=>t.title.toLowerCase().includes(e)||t.excerpt.toLowerCase().includes(e)||t.tags.some(t=>t.toLowerCase().includes(e))||t.author.toLowerCase().includes(e))}return t.sort((e,t)=>{switch(N){case"date":return new Date(t.publishDate).getTime()-new Date(e.publishDate).getTime();case"readTime":return e.readTime-t.readTime;case"title":return e.title.localeCompare(t.title);default:return 0}}),a&&(t=t.slice(0,a)),t},[i,j,N,e,a]),C=e=>new Date(e).toLocaleDateString("en-US",{year:"numeric",month:"long",day:"numeric"}),S=e=>h.t.find(t=>t.id===e)?.name||e,P=e=>({membership:"bg-purple-100 text-purple-800","bespoke-wigs":"bg-amber-100 text-amber-800","ready-made":"bg-blue-100 text-blue-800",education:"bg-green-100 text-green-800","care-tips":"bg-pink-100 text-pink-800",styling:"bg-orange-100 text-orange-800"})[e]||"bg-gray-100 text-gray-800";return(0,s.jsxs)("div",{className:"space-y-6",children:[!a&&(0,s.jsxs)("div",{className:"flex flex-col sm:flex-row gap-4 items-center justify-between",children:[(0,s.jsxs)("div",{className:"relative w-full sm:w-96",children:[(0,s.jsx)(m.A,{className:"absolute left-3 top-3 h-4 w-4 text-gray-400"}),(0,s.jsx)(c.p,{placeholder:"Search posts...",className:"pl-10",value:i,onChange:e=>v(e.target.value)})]}),(0,s.jsxs)("div",{className:"flex gap-2 w-full sm:w-auto",children:[(0,s.jsxs)(d.l6,{value:j,onValueChange:e=>k(e),children:[(0,s.jsxs)(d.bq,{className:"w-full sm:w-48",children:[(0,s.jsx)(p.A,{className:"h-4 w-4 mr-2"}),(0,s.jsx)(d.yv,{})]}),(0,s.jsxs)(d.gC,{children:[(0,s.jsx)(d.eb,{value:"all",children:"All Categories"}),h.t.map(e=>(0,s.jsx)(d.eb,{value:e.id,children:e.name},e.id))]})]}),(0,s.jsxs)(d.l6,{value:N,onValueChange:e=>T(e),children:[(0,s.jsx)(d.bq,{className:"w-full sm:w-32",children:(0,s.jsx)(d.yv,{})}),(0,s.jsxs)(d.gC,{children:[(0,s.jsx)(d.eb,{value:"date",children:"Latest"}),(0,s.jsx)(d.eb,{value:"readTime",children:"Quick Read"}),(0,s.jsx)(d.eb,{value:"title",children:"A-Z"})]})]})]})]}),!a&&(0,s.jsxs)("div",{className:"flex items-center justify-between",children:[(0,s.jsxs)("p",{className:"text-sm text-gray-600",children:[A.length," ",1===A.length?"post":"posts"," found"]}),e&&(0,s.jsxs)(u.E,{variant:"secondary",className:"flex items-center gap-1",children:[(0,s.jsx)(g.A,{className:"h-3 w-3"}),"Featured Posts"]})]}),(0,s.jsx)("div",{className:"grid gap-6 md:grid-cols-2 lg:grid-cols-3",children:A.map(e=>(0,s.jsxs)(n.Zp,{className:"group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 overflow-hidden",children:[e.imageUrl&&(0,s.jsx)("div",{className:"aspect-video overflow-hidden",children:(0,s.jsx)("img",{src:e.imageUrl,alt:e.title,className:"w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"})}),(0,s.jsxs)(n.aR,{className:"space-y-3",children:[(0,s.jsxs)("div",{className:"flex items-center justify-between",children:[(0,s.jsx)(u.E,{className:P(e.category),children:S(e.category)}),e.featured&&(0,s.jsx)(g.A,{className:"h-4 w-4 text-amber-500 fill-current"})]}),(0,s.jsx)(n.ZB,{className:"text-lg leading-tight group-hover:text-amber-700 transition-colors",children:e.title}),(0,s.jsx)(n.BT,{className:"line-clamp-2",children:e.excerpt})]}),(0,s.jsxs)(n.Wu,{className:"space-y-4",children:[(0,s.jsxs)("div",{className:"flex items-center gap-4 text-sm text-gray-500",children:[(0,s.jsxs)("div",{className:"flex items-center gap-1",children:[(0,s.jsx)(y.A,{className:"h-3 w-3"}),C(e.publishDate)]}),(0,s.jsxs)("div",{className:"flex items-center gap-1",children:[(0,s.jsx)(f.A,{className:"h-3 w-3"}),e.readTime," min read"]})]}),(0,s.jsxs)("div",{className:"flex items-center gap-2 text-sm text-gray-500",children:[(0,s.jsx)(w.A,{className:"h-3 w-3"}),e.author]}),(0,s.jsx)("div",{className:"flex flex-wrap gap-1",children:e.tags.slice(0,3).map(e=>(0,s.jsx)(u.E,{variant:"outline",className:"text-xs",children:e},e))}),(0,s.jsx)(o(),{href:`/blog/${e.id}`,children:(0,s.jsxs)(l.$,{variant:"ghost",className:"w-full justify-between text-amber-700 hover:bg-amber-50 group/button",children:[(0,s.jsxs)("span",{className:"flex items-center gap-2",children:[(0,s.jsx)(b.A,{className:"h-4 w-4"}),"Read More"]}),(0,s.jsx)(x.A,{className:"h-4 w-4 group-hover/button:translate-x-1 transition-transform"})]})})]})]},e.id))}),0===A.length&&(0,s.jsxs)("div",{className:"text-center py-12",children:[(0,s.jsx)(b.A,{className:"h-12 w-12 text-gray-400 mx-auto mb-4"}),(0,s.jsx)("h3",{className:"text-lg font-medium text-gray-900 mb-2",children:"No posts found"}),(0,s.jsx)("p",{className:"text-gray-500",children:"Try adjusting your search or filter criteria."})]}),a&&h.A.length>a&&(0,s.jsx)("div",{className:"text-center",children:(0,s.jsxs)(l.$,{variant:"outline",className:"border-amber-600 text-amber-700",children:["View All Posts",(0,s.jsx)(x.A,{className:"h-4 w-4 ml-2"})]})})]})}}};