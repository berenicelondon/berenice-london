"use strict";exports.id=478,exports.ids=[478],exports.modules={13:(e,t,n)=>{n.d(t,{J:()=>l});var i=n(687),r=n(3210),o=n(8148),a=n(4224),s=n(4780);let d=(0,a.F)("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"),l=r.forwardRef(({className:e,...t},n)=>(0,i.jsx)(o.b,{ref:n,className:(0,s.cn)(d(),e),...t}));l.displayName=o.b.displayName},1525:(e,t,n)=>{n.d(t,{G:()=>s});var i=n(687),r=n(9523),o=n(4493),a=n(9596);function s({amount:e,description:t,customerEmail:n,onSuccess:s,onError:d,metadata:l}){return(0,i.jsxs)(o.Zp,{className:"w-full max-w-md mx-auto",children:[(0,i.jsx)(o.aR,{children:(0,i.jsxs)(o.ZB,{className:"flex items-center gap-2",children:[(0,i.jsx)(a.A,{className:"h-5 w-5"}),"Payment Details"]})}),(0,i.jsxs)(o.Wu,{className:"space-y-6",children:[(0,i.jsx)("div",{className:"bg-blue-50 border border-blue-200 rounded-lg p-4",children:(0,i.jsxs)("p",{className:"text-sm text-blue-800",children:[(0,i.jsx)("strong",{children:"Demo Mode:"})," Payment processing is temporarily disabled. This is a demonstration of the checkout flow."]})}),(0,i.jsxs)("div",{className:"space-y-4",children:[(0,i.jsxs)("div",{className:"flex justify-between",children:[(0,i.jsx)("span",{children:"Amount:"}),(0,i.jsxs)("span",{className:"font-medium",children:["\xa3",e.toFixed(2)]})]}),t&&(0,i.jsx)("div",{className:"text-sm text-gray-600",children:t}),n&&(0,i.jsxs)("div",{className:"flex justify-between text-sm",children:[(0,i.jsx)("span",{children:"Email:"}),(0,i.jsx)("span",{children:n})]})]}),(0,i.jsx)(r.$,{onClick:()=>{setTimeout(()=>{s?.({id:`demo_${Date.now()}`,status:"succeeded",amount:100*e,currency:"gbp"})},2e3)},className:"w-full bg-green-600 hover:bg-green-700 text-white",children:"Complete Demo Order"}),(0,i.jsx)("p",{className:"text-xs text-gray-500 text-center",children:"Stripe payment integration will be enabled in the next update"})]})]})}},3520:(e,t,n)=>{n.d(t,{g:()=>r});class i{getTemplate(e,t){switch(e){case"booking_confirmation":return{subject:`Booking Confirmation - ${t.bookingReference}`,htmlContent:this.generateBookingConfirmationHTML(t),textContent:this.generateBookingConfirmationText(t)};case"booking_reminder":return{subject:`Appointment Reminder - Tomorrow at ${t.appointmentTime}`,htmlContent:this.generateBookingReminderHTML(t),textContent:this.generateBookingReminderText(t)};case"membership_welcome":return{subject:`Welcome to Berenice London - ${t.membershipTier} Membership`,htmlContent:this.generateMembershipWelcomeHTML(t),textContent:this.generateMembershipWelcomeText(t)};case"membership_upgrade":return{subject:`Membership Upgraded - Welcome to ${t.newTier}`,htmlContent:this.generateMembershipUpgradeHTML(t),textContent:this.generateMembershipUpgradeText(t)};case"payment_confirmation":return{subject:`Payment Received - \xa3${t.amount}`,htmlContent:this.generatePaymentConfirmationHTML(t),textContent:this.generatePaymentConfirmationText(t)};default:throw Error(`Unknown email template type: ${e}`)}}generateBookingConfirmationHTML(e){return`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #b45309, #d97706); color: white; padding: 30px; text-align: center; }
            .content { background: #fff; padding: 30px; border: 1px solid #e5e7eb; }
            .footer { background: #f9fafb; padding: 20px; text-align: center; font-size: 14px; color: #6b7280; }
            .button { display: inline-block; background: #d97706; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 10px 0; }
            .details { background: #fef3c7; padding: 20px; border-radius: 8px; margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Booking Confirmed</h1>
              <p>Thank you for choosing Berenice London</p>
            </div>
            <div class="content">
              <p>Dear ${e.userName},</p>
              <p>Your appointment has been successfully confirmed. We're excited to help you achieve your perfect hair solution.</p>

              <div class="details">
                <h3>Appointment Details</h3>
                <p><strong>Booking Reference:</strong> ${e.bookingReference}</p>
                <p><strong>Service:</strong> ${e.serviceName}</p>
                <p><strong>Date:</strong> ${e.appointmentDate}</p>
                <p><strong>Time:</strong> ${e.appointmentTime}</p>
                <p><strong>Duration:</strong> ${e.duration}</p>
                <p><strong>Location:</strong> ${e.location}</p>
                <p><strong>Total:</strong> \xa3${e.amount}</p>
              </div>

              <h3>What to Expect</h3>
              <ul>
                <li>Arrive 10 minutes early for check-in</li>
                <li>Bring any reference photos or inspiration</li>
                <li>Wear comfortable clothing</li>
                <li>Come with clean, dry hair if possible</li>
              </ul>

              <h3>Need to Make Changes?</h3>
              <p>If you need to reschedule or cancel, please contact us at least 24 hours in advance.</p>

              <div style="text-align: center; margin: 30px 0;">
                <a href="${this.baseUrl}/my-bookings" class="button">View My Bookings</a>
              </div>
            </div>
            <div class="footer">
              <p>Berenice London | Expert Hair Solutions</p>
              <p>Studio Address | London | Phone: 020 XXXX XXXX</p>
            </div>
          </div>
        </body>
      </html>
    `}generateBookingConfirmationText(e){return`
      BOOKING CONFIRMED - BERENICE LONDON

      Dear ${e.userName},

      Your appointment has been successfully confirmed.

      APPOINTMENT DETAILS:
      Booking Reference: ${e.bookingReference}
      Service: ${e.serviceName}
      Date: ${e.appointmentDate}
      Time: ${e.appointmentTime}
      Duration: ${e.duration}
      Location: ${e.location}
      Total: \xa3${e.amount}

      WHAT TO EXPECT:
      • Arrive 10 minutes early for check-in
      • Bring any reference photos or inspiration
      • Wear comfortable clothing
      • Come with clean, dry hair if possible

      Need to make changes? Contact us at least 24 hours in advance.

      View your bookings: ${this.baseUrl}/my-bookings

      Thank you for choosing Berenice London!
    `}generateBookingReminderHTML(e){return`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #b45309, #d97706); color: white; padding: 30px; text-align: center; }
            .content { background: #fff; padding: 30px; border: 1px solid #e5e7eb; }
            .reminder-box { background: #fef3c7; padding: 20px; border-radius: 8px; text-align: center; margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Appointment Reminder</h1>
            </div>
            <div class="content">
              <p>Dear ${e.userName},</p>

              <div class="reminder-box">
                <h2>Your appointment is tomorrow!</h2>
                <p><strong>${e.serviceName}</strong></p>
                <p>${e.appointmentDate} at ${e.appointmentTime}</p>
              </div>

              <p>We're looking forward to seeing you tomorrow. Please remember to:</p>
              <ul>
                <li>Arrive 10 minutes early</li>
                <li>Bring any inspiration photos</li>
                <li>Wear comfortable clothing</li>
              </ul>

              <p>If you need to make any last-minute changes, please call us as soon as possible.</p>
            </div>
          </div>
        </body>
      </html>
    `}generateBookingReminderText(e){return`
      APPOINTMENT REMINDER - BERENICE LONDON

      Dear ${e.userName},

      Your appointment is tomorrow!

      ${e.serviceName}
      ${e.appointmentDate} at ${e.appointmentTime}

      Please remember to:
      • Arrive 10 minutes early
      • Bring any inspiration photos
      • Wear comfortable clothing

      See you tomorrow!
    `}generateMembershipWelcomeHTML(e){return`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #b45309, #d97706); color: white; padding: 30px; text-align: center; }
            .content { background: #fff; padding: 30px; border: 1px solid #e5e7eb; }
            .benefits { background: #fef3c7; padding: 20px; border-radius: 8px; margin: 20px 0; }
            .button { display: inline-block; background: #d97706; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 10px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Welcome to Berenice London!</h1>
              <p>Your ${e.membershipTier} membership is now active</p>
            </div>
            <div class="content">
              <p>Dear ${e.userName},</p>
              <p>Welcome to the Berenice London family! We're thrilled to have you as a ${e.membershipTier} member.</p>

              <div class="benefits">
                <h3>Your ${e.membershipTier} Benefits Include:</h3>
                ${this.getMembershipBenefitsHTML(e.membershipTier)}
              </div>

              <h3>Getting Started</h3>
              <p>Your member dashboard is ready for you with exclusive content, priority booking, and personalized recommendations.</p>

              <div style="text-align: center; margin: 30px 0;">
                <a href="${this.baseUrl}/dashboard" class="button">Access Your Dashboard</a>
              </div>
            </div>
          </div>
        </body>
      </html>
    `}generateMembershipWelcomeText(e){return`
      WELCOME TO BERENICE LONDON!

      Dear ${e.userName},

      Your ${e.membershipTier} membership is now active.

      Access your member dashboard: ${this.baseUrl}/dashboard

      Welcome to the family!
    `}generateMembershipUpgradeHTML(e){return`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #b45309, #d97706); color: white; padding: 30px; text-align: center; }
            .content { background: #fff; padding: 30px; border: 1px solid #e5e7eb; }
            .upgrade-box { background: #fef3c7; padding: 20px; border-radius: 8px; text-align: center; margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Membership Upgraded!</h1>
              <p>Welcome to ${e.newTier}</p>
            </div>
            <div class="content">
              <p>Dear ${e.userName},</p>

              <div class="upgrade-box">
                <h2>Congratulations on your upgrade!</h2>
                <p>You now have access to exclusive ${e.newTier} benefits</p>
              </div>

              <h3>Your New Benefits:</h3>
              ${this.getMembershipBenefitsHTML(e.newTier)}
            </div>
          </div>
        </body>
      </html>
    `}generateMembershipUpgradeText(e){return`
      MEMBERSHIP UPGRADED - BERENICE LONDON

      Dear ${e.userName},

      Congratulations! Your membership has been upgraded to ${e.newTier}.

      Enjoy your new benefits!
    `}generatePaymentConfirmationHTML(e){return`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #b45309, #d97706); color: white; padding: 30px; text-align: center; }
            .content { background: #fff; padding: 30px; border: 1px solid #e5e7eb; }
            .payment-details { background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Payment Received</h1>
              <p>Thank you for your payment</p>
            </div>
            <div class="content">
              <p>Dear ${e.userName},</p>
              <p>We've successfully processed your payment.</p>

              <div class="payment-details">
                <h3>Payment Details</h3>
                <p><strong>Amount:</strong> \xa3${e.amount}</p>
                <p><strong>Payment ID:</strong> ${e.paymentId}</p>
                <p><strong>Date:</strong> ${e.paymentDate}</p>
                <p><strong>Description:</strong> ${e.description}</p>
              </div>

              <p>You should receive the benefits of your purchase immediately.</p>
            </div>
          </div>
        </body>
      </html>
    `}generatePaymentConfirmationText(e){return`
      PAYMENT RECEIVED - BERENICE LONDON

      Dear ${e.userName},

      We've successfully processed your payment.

      Amount: \xa3${e.amount}
      Payment ID: ${e.paymentId}
      Date: ${e.paymentDate}

      Thank you!
    `}getMembershipBenefitsHTML(e){let t=this.getMembershipBenefits(e);return`<ul>${t.map(e=>`<li>${e}</li>`).join("")}</ul>`}getMembershipBenefits(e){switch(e){case"premium":return["15% discount on all services","Priority booking","Monthly styling tips newsletter","Free product samples"];case"elite":return["25% discount on all services","Priority booking","Monthly styling tips newsletter","Free product samples","1-on-1 styling sessions","Exclusive event invitations"];default:return["Access to member blog","Basic booking system","Community access"]}}async sendEmail(e,t){try{let n=this.getTemplate(e,t);console.log("\uD83D\uDCE7 Email Notification:",{to:t.userEmail,subject:n.subject,type:e,data:t}),await new Promise(e=>setTimeout(e,500));let i=`msg_${Date.now()}_${Math.random().toString(36).substr(2,9)}`;return{success:!0,messageId:i}}catch(e){return console.error("Email sending failed:",e),{success:!1,error:"Failed to send email notification"}}}async sendBookingConfirmation(e){return this.sendEmail("booking_confirmation",e)}async sendBookingReminder(e){return this.sendEmail("booking_reminder",e)}async sendMembershipWelcome(e){return this.sendEmail("membership_welcome",e)}async sendMembershipUpgrade(e){return this.sendEmail("membership_upgrade",e)}async sendPaymentConfirmation(e){return this.sendEmail("payment_confirmation",e)}constructor(){this.baseUrl="https://berenice-london.com"}}let r=new i},9667:(e,t,n)=>{n.d(t,{p:()=>a});var i=n(687),r=n(3210),o=n(4780);let a=r.forwardRef(({className:e,type:t,...n},r)=>(0,i.jsx)("input",{type:t,className:(0,o.cn)("flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-base shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",e),ref:r,...n}));a.displayName="Input"}};