1:"$Sreact.fragment"
4:I[7558,["177","static/chunks/app/layout-555960ecade8246d.js"],"Analytics"]
5:I[5476,["177","static/chunks/app/layout-555960ecade8246d.js"],"default"]
6:I[7555,[],""]
7:I[1295,[],""]
8:I[9243,["177","static/chunks/app/layout-555960ecade8246d.js"],""]
9:I[894,[],"ClientPageRoot"]
a:I[4269,["500","static/chunks/500-024941616dc67bd8.js","688","static/chunks/688-a41aaf82ca249f3b.js","533","static/chunks/533-b79b4f66cf76f198.js","388","static/chunks/388-e6807da5a99d5f89.js","831","static/chunks/app/blog/page-69ce9f8c84abc14a.js"],"default"]
d:I[9665,[],"MetadataBoundary"]
f:I[9665,[],"OutletBoundary"]
12:I[4911,[],"AsyncMetadataOutlet"]
14:I[9665,[],"ViewportBoundary"]
16:I[6614,[],""]
:HL["/_next/static/media/569ce4b8f30dc480-s.p.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/93f479601ee12b01-s.p.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/css/6840c9415f20b4b3.css","style"]
2:T450,
            /* Critical above-the-fold CSS */
            * { box-sizing: border-box; }
            html { scroll-behavior: smooth; }
            body {
              margin: 0;
              font-family: var(--font-geist-sans), -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
              line-height: 1.6;
              color: #1c1917;
              background: linear-gradient(135deg, #fef3c7, #fed7aa);
              min-height: 100vh;
            }
            .loading-spinner {
              display: inline-block;
              width: 20px;
              height: 20px;
              border: 3px solid #f3f3f3;
              border-top: 3px solid #b45309;
              border-radius: 50%;
              animation: spin 1s linear infinite;
            }
            @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
            .nav-loading { height: 4rem; background: rgba(255, 255, 255, 0.9); backdrop-filter: blur(8px); }
            .hero-loading { min-height: 80vh; background: linear-gradient(135deg, #fef3c7, #fed7aa); }
          3:Ted6,{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@context": "https://schema.org",
      "@type": "Organization",
      "name": "Berenice London",
      "description": "Expert craftsmanship in bespoke wigs, hairpieces, and professional hair education. Transforming lives through exceptional hair solutions with over 20 years of expertise.",
      "url": "https://berenicelondon.co.uk",
      "logo": "https://berenicelondon.co.uk/images/logo.png",
      "image": "https://berenicelondon.co.uk/images/business-photo.jpg",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "Professional Studio",
        "addressLocality": "London",
        "addressCountry": "GB"
      },
      "contactPoint": {
        "@type": "ContactPoint",
        "telephone": "+44-20-XXXX-XXXX",
        "contactType": "customer service",
        "availableLanguage": "English"
      },
      "sameAs": [
        "https://facebook.com/BereniceLondon",
        "https://twitter.com/BereniceLondon",
        "https://instagram.com/berenice.london",
        "https://linkedin.com/company/berenice-london"
      ],
      "foundingDate": "2004",
      "founder": {
        "@type": "Person",
        "name": "Berenice"
      },
      "areaServed": {
        "@type": "Country",
        "name": "United Kingdom"
      },
      "serviceArea": {
        "@type": "GeoCircle",
        "geoMidpoint": {
          "@type": "GeoCoordinates",
          "latitude": 51.5074,
          "longitude": -0.1278
        },
        "geoRadius": 50000
      }
    },
    {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "@id": "https://berenicelondon.co.uk/#business",
      "name": "Berenice London",
      "description": "Expert craftsmanship in bespoke wigs, hairpieces, and professional hair education. Transforming lives through exceptional hair solutions with over 20 years of expertise.",
      "url": "https://berenicelondon.co.uk",
      "telephone": "+44-20-XXXX-XXXX",
      "priceRange": "£££",
      "image": [
        "https://berenicelondon.co.uk/images/business-photo-1.jpg",
        "https://berenicelondon.co.uk/images/business-photo-2.jpg",
        "https://berenicelondon.co.uk/images/business-photo-3.jpg"
      ],
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "Professional Studio",
        "addressLocality": "London",
        "postalCode": "SW1A 1AA",
        "addressCountry": "GB"
      },
      "geo": {
        "@type": "GeoCoordinates",
        "latitude": 51.5074,
        "longitude": -0.1278
      },
      "openingHours": [
        "Mo-Fr 09:00-18:00",
        "Sa 10:00-16:00"
      ],
      "paymentAccepted": [
        "Cash",
        "Credit Card",
        "Debit Card"
      ],
      "currenciesAccepted": "GBP",
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": 4.9,
        "reviewCount": 127,
        "bestRating": 5,
        "worstRating": 1
      }
    },
    {
      "@context": "https://schema.org",
      "@type": "WebSite",
      "@id": "https://berenicelondon.co.uk/#website",
      "url": "https://berenicelondon.co.uk",
      "name": "Berenice London",
      "description": "Expert craftsmanship in bespoke wigs, hairpieces, and professional hair education. Transforming lives through exceptional hair solutions with over 20 years of expertise.",
      "inLanguage": "en-GB",
      "publisher": {
        "@id": "https://berenicelondon.co.uk/#business"
      },
      "potentialAction": {
        "@type": "SearchAction",
        "target": {
          "@type": "EntryPoint",
          "urlTemplate": "https://berenicelondon.co.uk/shop?search={search_term_string}"
        },
        "query-input": "required name=search_term_string"
      }
    }
  ]
}0:{"P":null,"b":"UGyuo5o3rLJdEZl77hpk_","p":"","c":["","blog"],"i":false,"f":[[["",{"children":["blog",{"children":["__PAGE__",{}]}]},"$undefined","$undefined",true],["",["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/6840c9415f20b4b3.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","html",null,{"lang":"en-GB","className":"__variable_5cfdac __variable_9a8899","children":[["$","head",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"$2"}}],["$","link",null,{"rel":"preload","href":"/fonts/inter-var.woff2","as":"font","type":"font/woff2","crossOrigin":"anonymous"}],["$","link",null,{"rel":"icon","type":"image/x-icon","href":"/favicon.ico"}],["$","link",null,{"rel":"icon","type":"image/png","sizes":"32x32","href":"/favicon-32x32.png"}],["$","link",null,{"rel":"icon","type":"image/png","sizes":"16x16","href":"/favicon-16x16.png"}],["$","link",null,{"rel":"apple-touch-icon","sizes":"180x180","href":"/apple-touch-icon.png"}],["$","link",null,{"rel":"manifest","href":"/site.webmanifest"}],["$","meta",null,{"name":"theme-color","content":"#b45309"}],["$","meta",null,{"name":"msapplication-TileColor","content":"#b45309"}],["$","meta",null,{"name":"msapplication-config","content":"/browserconfig.xml"}],["$","link",null,{"rel":"dns-prefetch","href":"//images.unsplash.com"}],["$","link",null,{"rel":"dns-prefetch","href":"//fonts.googleapis.com"}],["$","link",null,{"rel":"dns-prefetch","href":"//js.stripe.com"}],["$","link",null,{"rel":"preconnect","href":"https://fonts.googleapis.com"}],["$","link",null,{"rel":"preconnect","href":"https://fonts.gstatic.com","crossOrigin":"anonymous"}],["$","meta",null,{"httpEquiv":"X-Content-Type-Options","content":"nosniff"}],["$","meta",null,{"httpEquiv":"X-Frame-Options","content":"SAMEORIGIN"}],["$","meta",null,{"httpEquiv":"X-XSS-Protection","content":"1; mode=block"}],["$","meta",null,{"httpEquiv":"Referrer-Policy","content":"strict-origin-when-cross-origin"}],["$","link",null,{"rel":"preload","href":"/images/hero-background.jpg","as":"image","type":"image/jpeg"}],["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"$3"}}],["$","$L4",null,{}],["$","script",null,{"id":"breadcrumb-schema","type":"application/ld+json"}]]}],["$","body",null,{"suppressHydrationWarning":true,"className":"antialiased","children":[["$","$L5",null,{"children":["$","$L6",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L7",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}],["$","$L8",null,{"crossOrigin":"anonymous","src":"//unpkg.com/same-runtime/dist/index.global.js","strategy":"afterInteractive"}]]}]]}]]}],{"children":["blog",["$","$1","c",{"children":[null,["$","$L6",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L7",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],{"children":["__PAGE__",["$","$1","c",{"children":[["$","$L9",null,{"Component":"$a","searchParams":{},"params":{},"promises":["$@b","$@c"]}],["$","$Ld",null,{"children":"$Le"}],null,["$","$Lf",null,{"children":["$L10","$L11",["$","$L12",null,{"promise":"$@13"}]]}]]}],{},null,false]},null,false]},null,false],["$","$1","h",{"children":[null,["$","$1","WjwuAEy46klPcNbWKUdin",{"children":[["$","$L14",null,{"children":"$L15"}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],null]}],false]],"m":"$undefined","G":["$16","$undefined"],"s":false,"S":true}
17:"$Sreact.suspense"
18:I[4911,[],"AsyncMetadata"]
b:{}
c:{}
e:["$","$17",null,{"fallback":null,"children":["$","$L18",null,{"promise":"$@19"}]}]
11:null
15:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
10:null
19:{"metadata":[["$","title","0",{"children":"Berenice London | Premium Hair Solutions | Berenice London"}],["$","meta","1",{"name":"description","content":"Expert craftsmanship in bespoke wigs, hairpieces, and professional hair education. Transforming lives through exceptional hair solutions with over 20 years of expertise in London."}],["$","meta","2",{"name":"author","content":"Berenice London"}],["$","meta","3",{"name":"keywords","content":"bespoke wigs, hair toppers, wig making, hair loss solutions, professional wigs, human hair wigs, wig consultation, hair education, London wig specialist, custom hairpieces, alopecia wigs, cancer wigs, medical wigs, theatrical wigs, hair extensions, bespoke wigs London, premium hair solutions, custom hairpieces, professional wig making, hair loss solutions, medical wigs, alopecia wigs, cancer patient wigs, theatrical wigs, hair education courses, wig consultation London"}],["$","meta","4",{"name":"creator","content":"Berenice London"}],["$","meta","5",{"name":"publisher","content":"Berenice London"}],["$","meta","6",{"name":"robots","content":"index,follow"}],["$","link","7",{"rel":"canonical","href":"https://berenicelondon.co.uk/"}],["$","meta","8",{"name":"google-site-verification","content":"your-google-verification-code"}],["$","meta","9",{"name":"yandex-verification","content":"your-yandex-verification-code"}],["$","meta","10",{"name":"facebook-domain-verification","content":"your-facebook-verification-code"}],["$","meta","11",{"property":"og:title","content":"Berenice London | Premium Hair Solutions | Berenice London"}],["$","meta","12",{"property":"og:description","content":"Expert craftsmanship in bespoke wigs, hairpieces, and professional hair education. Transforming lives through exceptional hair solutions with over 20 years of expertise in London."}],["$","meta","13",{"property":"og:url","content":"https://berenicelondon.co.uk/"}],["$","meta","14",{"property":"og:site_name","content":"Berenice London"}],["$","meta","15",{"property":"og:locale","content":"en_GB"}],["$","meta","16",{"property":"og:country_name","content":"United Kingdom"}],["$","meta","17",{"property":"og:image","content":"https://berenicelondon.co.uk/images/og-default.jpg"}],["$","meta","18",{"property":"og:image:width","content":"1200"}],["$","meta","19",{"property":"og:image:height","content":"630"}],["$","meta","20",{"property":"og:image:alt","content":"Berenice London | Premium Hair Solutions | Berenice London"}],["$","meta","21",{"property":"og:type","content":"website"}],["$","meta","22",{"name":"twitter:card","content":"summary_large_image"}],["$","meta","23",{"name":"twitter:site","content":"@BereniceLondon"}],["$","meta","24",{"name":"twitter:creator","content":"@BereniceLondon"}],["$","meta","25",{"name":"twitter:title","content":"Berenice London | Premium Hair Solutions | Berenice London"}],["$","meta","26",{"name":"twitter:description","content":"Expert craftsmanship in bespoke wigs, hairpieces, and professional hair education. Transforming lives through exceptional hair solutions with over 20 years of expertise in London."}],["$","meta","27",{"name":"twitter:image","content":"https://berenicelondon.co.uk/images/og-default.jpg"}]],"error":null,"digest":"$undefined"}
13:{"metadata":"$19:metadata","error":null,"digest":"$undefined"}
