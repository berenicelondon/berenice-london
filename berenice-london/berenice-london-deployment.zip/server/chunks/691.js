"use strict";exports.id=691,exports.ids=[691],exports.modules={13520:(e,t,r)=>{r.d(t,{g:()=>a});class n{getTemplate(e,t){switch(e){case"booking_confirmation":return{subject:`Booking Confirmation - ${t.bookingReference}`,htmlContent:this.generateBookingConfirmationHTML(t),textContent:this.generateBookingConfirmationText(t)};case"booking_reminder":return{subject:`Appointment Reminder - Tomorrow at ${t.appointmentTime}`,htmlContent:this.generateBookingReminderHTML(t),textContent:this.generateBookingReminderText(t)};case"membership_welcome":return{subject:`Welcome to Berenice London - ${t.membershipTier} Membership`,htmlContent:this.generateMembershipWelcomeHTML(t),textContent:this.generateMembershipWelcomeText(t)};case"membership_upgrade":return{subject:`Membership Upgraded - Welcome to ${t.newTier}`,htmlContent:this.generateMembershipUpgradeHTML(t),textContent:this.generateMembershipUpgradeText(t)};case"payment_confirmation":return{subject:`Payment Received - \xa3${t.amount}`,htmlContent:this.generatePaymentConfirmationHTML(t),textContent:this.generatePaymentConfirmationText(t)};default:throw Error(`Unknown email template type: ${e}`)}}generateBookingConfirmationHTML(e){return`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #b45309, #d97706); color: white; padding: 30px; text-align: center; }
            .content { background: #fff; padding: 30px; border: 1px solid #e5e7eb; }
            .footer { background: #f9fafb; padding: 20px; text-align: center; font-size: 14px; color: #6b7280; }
            .button { display: inline-block; background: #d97706; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 10px 0; }
            .details { background: #fef3c7; padding: 20px; border-radius: 8px; margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Booking Confirmed</h1>
              <p>Thank you for choosing Berenice London</p>
            </div>
            <div class="content">
              <p>Dear ${e.userName},</p>
              <p>Your appointment has been successfully confirmed. We're excited to help you achieve your perfect hair solution.</p>

              <div class="details">
                <h3>Appointment Details</h3>
                <p><strong>Booking Reference:</strong> ${e.bookingReference}</p>
                <p><strong>Service:</strong> ${e.serviceName}</p>
                <p><strong>Date:</strong> ${e.appointmentDate}</p>
                <p><strong>Time:</strong> ${e.appointmentTime}</p>
                <p><strong>Duration:</strong> ${e.duration}</p>
                <p><strong>Location:</strong> ${e.location}</p>
                <p><strong>Total:</strong> \xa3${e.amount}</p>
              </div>

              <h3>What to Expect</h3>
              <ul>
                <li>Arrive 10 minutes early for check-in</li>
                <li>Bring any reference photos or inspiration</li>
                <li>Wear comfortable clothing</li>
                <li>Come with clean, dry hair if possible</li>
              </ul>

              <h3>Need to Make Changes?</h3>
              <p>If you need to reschedule or cancel, please contact us at least 24 hours in advance.</p>

              <div style="text-align: center; margin: 30px 0;">
                <a href="${this.baseUrl}/my-bookings" class="button">View My Bookings</a>
              </div>
            </div>
            <div class="footer">
              <p>Berenice London | Expert Hair Solutions</p>
              <p>Studio Address | London | Phone: 020 XXXX XXXX</p>
            </div>
          </div>
        </body>
      </html>
    `}generateBookingConfirmationText(e){return`
      BOOKING CONFIRMED - BERENICE LONDON

      Dear ${e.userName},

      Your appointment has been successfully confirmed.

      APPOINTMENT DETAILS:
      Booking Reference: ${e.bookingReference}
      Service: ${e.serviceName}
      Date: ${e.appointmentDate}
      Time: ${e.appointmentTime}
      Duration: ${e.duration}
      Location: ${e.location}
      Total: \xa3${e.amount}

      WHAT TO EXPECT:
      • Arrive 10 minutes early for check-in
      • Bring any reference photos or inspiration
      • Wear comfortable clothing
      • Come with clean, dry hair if possible

      Need to make changes? Contact us at least 24 hours in advance.

      View your bookings: ${this.baseUrl}/my-bookings

      Thank you for choosing Berenice London!
    `}generateBookingReminderHTML(e){return`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #b45309, #d97706); color: white; padding: 30px; text-align: center; }
            .content { background: #fff; padding: 30px; border: 1px solid #e5e7eb; }
            .reminder-box { background: #fef3c7; padding: 20px; border-radius: 8px; text-align: center; margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Appointment Reminder</h1>
            </div>
            <div class="content">
              <p>Dear ${e.userName},</p>

              <div class="reminder-box">
                <h2>Your appointment is tomorrow!</h2>
                <p><strong>${e.serviceName}</strong></p>
                <p>${e.appointmentDate} at ${e.appointmentTime}</p>
              </div>

              <p>We're looking forward to seeing you tomorrow. Please remember to:</p>
              <ul>
                <li>Arrive 10 minutes early</li>
                <li>Bring any inspiration photos</li>
                <li>Wear comfortable clothing</li>
              </ul>

              <p>If you need to make any last-minute changes, please call us as soon as possible.</p>
            </div>
          </div>
        </body>
      </html>
    `}generateBookingReminderText(e){return`
      APPOINTMENT REMINDER - BERENICE LONDON

      Dear ${e.userName},

      Your appointment is tomorrow!

      ${e.serviceName}
      ${e.appointmentDate} at ${e.appointmentTime}

      Please remember to:
      • Arrive 10 minutes early
      • Bring any inspiration photos
      • Wear comfortable clothing

      See you tomorrow!
    `}generateMembershipWelcomeHTML(e){return`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #b45309, #d97706); color: white; padding: 30px; text-align: center; }
            .content { background: #fff; padding: 30px; border: 1px solid #e5e7eb; }
            .benefits { background: #fef3c7; padding: 20px; border-radius: 8px; margin: 20px 0; }
            .button { display: inline-block; background: #d97706; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 10px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Welcome to Berenice London!</h1>
              <p>Your ${e.membershipTier} membership is now active</p>
            </div>
            <div class="content">
              <p>Dear ${e.userName},</p>
              <p>Welcome to the Berenice London family! We're thrilled to have you as a ${e.membershipTier} member.</p>

              <div class="benefits">
                <h3>Your ${e.membershipTier} Benefits Include:</h3>
                ${this.getMembershipBenefitsHTML(e.membershipTier)}
              </div>

              <h3>Getting Started</h3>
              <p>Your member dashboard is ready for you with exclusive content, priority booking, and personalized recommendations.</p>

              <div style="text-align: center; margin: 30px 0;">
                <a href="${this.baseUrl}/dashboard" class="button">Access Your Dashboard</a>
              </div>
            </div>
          </div>
        </body>
      </html>
    `}generateMembershipWelcomeText(e){return`
      WELCOME TO BERENICE LONDON!

      Dear ${e.userName},

      Your ${e.membershipTier} membership is now active.

      Access your member dashboard: ${this.baseUrl}/dashboard

      Welcome to the family!
    `}generateMembershipUpgradeHTML(e){return`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #b45309, #d97706); color: white; padding: 30px; text-align: center; }
            .content { background: #fff; padding: 30px; border: 1px solid #e5e7eb; }
            .upgrade-box { background: #fef3c7; padding: 20px; border-radius: 8px; text-align: center; margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Membership Upgraded!</h1>
              <p>Welcome to ${e.newTier}</p>
            </div>
            <div class="content">
              <p>Dear ${e.userName},</p>

              <div class="upgrade-box">
                <h2>Congratulations on your upgrade!</h2>
                <p>You now have access to exclusive ${e.newTier} benefits</p>
              </div>

              <h3>Your New Benefits:</h3>
              ${this.getMembershipBenefitsHTML(e.newTier)}
            </div>
          </div>
        </body>
      </html>
    `}generateMembershipUpgradeText(e){return`
      MEMBERSHIP UPGRADED - BERENICE LONDON

      Dear ${e.userName},

      Congratulations! Your membership has been upgraded to ${e.newTier}.

      Enjoy your new benefits!
    `}generatePaymentConfirmationHTML(e){return`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #b45309, #d97706); color: white; padding: 30px; text-align: center; }
            .content { background: #fff; padding: 30px; border: 1px solid #e5e7eb; }
            .payment-details { background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Payment Received</h1>
              <p>Thank you for your payment</p>
            </div>
            <div class="content">
              <p>Dear ${e.userName},</p>
              <p>We've successfully processed your payment.</p>

              <div class="payment-details">
                <h3>Payment Details</h3>
                <p><strong>Amount:</strong> \xa3${e.amount}</p>
                <p><strong>Payment ID:</strong> ${e.paymentId}</p>
                <p><strong>Date:</strong> ${e.paymentDate}</p>
                <p><strong>Description:</strong> ${e.description}</p>
              </div>

              <p>You should receive the benefits of your purchase immediately.</p>
            </div>
          </div>
        </body>
      </html>
    `}generatePaymentConfirmationText(e){return`
      PAYMENT RECEIVED - BERENICE LONDON

      Dear ${e.userName},

      We've successfully processed your payment.

      Amount: \xa3${e.amount}
      Payment ID: ${e.paymentId}
      Date: ${e.paymentDate}

      Thank you!
    `}getMembershipBenefitsHTML(e){let t=this.getMembershipBenefits(e);return`<ul>${t.map(e=>`<li>${e}</li>`).join("")}</ul>`}getMembershipBenefits(e){switch(e){case"premium":return["15% discount on all services","Priority booking","Monthly styling tips newsletter","Free product samples"];case"elite":return["25% discount on all services","Priority booking","Monthly styling tips newsletter","Free product samples","1-on-1 styling sessions","Exclusive event invitations"];default:return["Access to member blog","Basic booking system","Community access"]}}async sendEmail(e,t){try{let r=this.getTemplate(e,t);console.log("\uD83D\uDCE7 Email Notification:",{to:t.userEmail,subject:r.subject,type:e,data:t}),await new Promise(e=>setTimeout(e,500));let n=`msg_${Date.now()}_${Math.random().toString(36).substr(2,9)}`;return{success:!0,messageId:n}}catch(e){return console.error("Email sending failed:",e),{success:!1,error:"Failed to send email notification"}}}async sendBookingConfirmation(e){return this.sendEmail("booking_confirmation",e)}async sendBookingReminder(e){return this.sendEmail("booking_reminder",e)}async sendMembershipWelcome(e){return this.sendEmail("membership_welcome",e)}async sendMembershipUpgrade(e){return this.sendEmail("membership_upgrade",e)}async sendPaymentConfirmation(e){return this.sendEmail("payment_confirmation",e)}constructor(){this.baseUrl="https://berenice-london.com"}}let a=new n},66319:(e,t,r)=>{let n;r.d(t,{G:()=>w});var a=r(76392),i=r(43210),s=r(46299),o=r(29523),l=r(44493),d=r(96834),c=r(91821),m=r(3662),p=r(53597),h=r(85535),u=r(72963),g=r(11516),b=r(29596),x=r(39010);let f={publishableKey:process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY_LIVE||"",secretKey:process.env.STRIPE_SECRET_KEY_LIVE,webhookSecret:process.env.STRIPE_WEBHOOK_SECRET_LIVE},y=(e,t="GBP")=>new Intl.NumberFormat("en-GB",{style:"currency",currency:t}).format(e/100),v=e=>Math.round(100*e),N=(n||(n=f.publishableKey?(0,x.c)(f.publishableKey):Promise.resolve(null)),n),T=({amount:e,currency:t="GBP",description:r,customerEmail:n,onSuccess:l,onError:x,clientSecret:f,metadata:N})=>{let T=(0,s.t2)(),w=(0,s.HH)(),[j,E]=(0,i.useState)(!1),[k,$]=(0,i.useState)(null),[B,P]=(0,i.useState)(!1),C=async e=>{if(e.preventDefault(),!T||!w)return;E(!0),$(null);let t=w.getElement(s.hA);if(!t){$("Card element not found"),E(!1);return}let{error:r,paymentIntent:a}=await T.confirmCardPayment(f,{payment_method:{card:t,billing_details:{email:n}}});E(!1),r?($(r.message||"An error occurred"),x(r.message||"Payment failed")):a&&"succeeded"===a.status&&(P(!0),l(a))};return B?(0,a.jsxs)("div",{className:"text-center p-8",children:[(0,a.jsx)(m.A,{className:"h-16 w-16 text-green-500 mx-auto mb-4"}),(0,a.jsx)("h3",{className:"text-xl font-semibold text-green-700 mb-2",children:"Payment Successful!"}),(0,a.jsx)("p",{className:"text-gray-600",children:"Your payment has been processed securely."})]}):(0,a.jsxs)("form",{onSubmit:C,className:"space-y-6",children:[(0,a.jsxs)("div",{className:"bg-amber-50 border border-amber-200 rounded-lg p-4",children:[(0,a.jsxs)("div",{className:"flex justify-between items-center mb-2",children:[(0,a.jsx)("span",{className:"font-medium text-gray-700",children:"Amount to pay:"}),(0,a.jsx)("span",{className:"text-2xl font-bold text-amber-700",children:y(v(e),t)})]}),(0,a.jsx)("p",{className:"text-sm text-gray-600",children:r})]}),(0,a.jsxs)("div",{className:"space-y-4",children:[(0,a.jsx)("label",{className:"block text-sm font-medium text-gray-700",children:"Card Details"}),(0,a.jsx)("div",{className:"border border-gray-300 rounded-lg p-4 bg-white",children:(0,a.jsx)(s.hA,{options:{style:{base:{fontSize:"16px",color:"#424770","::placeholder":{color:"#aab7c4"},fontFamily:"system-ui, -apple-system, sans-serif"},invalid:{color:"#9e2146"}},hidePostalCode:!0}})})]}),(0,a.jsxs)("div",{className:"flex items-center justify-center gap-4 text-sm text-gray-500",children:[(0,a.jsxs)("div",{className:"flex items-center gap-1",children:[(0,a.jsx)(p.A,{className:"h-4 w-4"}),(0,a.jsx)("span",{children:"SSL Encrypted"})]}),(0,a.jsxs)("div",{className:"flex items-center gap-1",children:[(0,a.jsx)(h.A,{className:"h-4 w-4"}),(0,a.jsx)("span",{children:"Secure Payment"})]})]}),k&&(0,a.jsxs)(c.Fc,{variant:"destructive",children:[(0,a.jsx)(u.A,{className:"h-4 w-4"}),(0,a.jsx)(c.TN,{children:k})]}),(0,a.jsx)(o.$,{type:"submit",className:"w-full bg-amber-700 hover:bg-amber-800 text-white",disabled:!T||j,children:j?(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(g.A,{className:"mr-2 h-4 w-4 animate-spin"}),"Processing Payment..."]}):(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(b.A,{className:"mr-2 h-4 w-4"}),"Pay ",y(v(e),t)]})}),(0,a.jsx)("div",{className:"text-center",children:(0,a.jsx)(d.E,{variant:"outline",className:"text-xs",children:"Powered by Stripe"})})]})};function w(e){let[t,r]=(0,i.useState)(null),[n,o]=(0,i.useState)(!0),[d,m]=(0,i.useState)(null);return n?(0,a.jsxs)(l.Zp,{className:"max-w-md mx-auto",children:[(0,a.jsxs)(l.aR,{children:[(0,a.jsxs)(l.ZB,{className:"flex items-center gap-2",children:[(0,a.jsx)(b.A,{className:"h-5 w-5"}),"Processing Payment"]}),(0,a.jsx)(l.BT,{children:"Initializing secure payment..."})]}),(0,a.jsx)(l.Wu,{className:"flex items-center justify-center py-8",children:(0,a.jsx)(g.A,{className:"h-8 w-8 animate-spin text-amber-600"})})]}):d||!t?(0,a.jsxs)(l.Zp,{className:"max-w-md mx-auto",children:[(0,a.jsx)(l.aR,{children:(0,a.jsxs)(l.ZB,{className:"flex items-center gap-2 text-red-600",children:[(0,a.jsx)(u.A,{className:"h-5 w-5"}),"Payment Error"]})}),(0,a.jsx)(l.Wu,{children:(0,a.jsx)(c.Fc,{variant:"destructive",children:(0,a.jsx)(c.TN,{children:d||"Unable to initialize payment. Please try again."})})})]}):(0,a.jsxs)(l.Zp,{className:"max-w-md mx-auto",children:[(0,a.jsxs)(l.aR,{children:[(0,a.jsxs)(l.ZB,{className:"flex items-center gap-2",children:[(0,a.jsx)(b.A,{className:"h-5 w-5"}),"Secure Payment"]}),(0,a.jsx)(l.BT,{children:"Complete your payment securely with Stripe"})]}),(0,a.jsx)(l.Wu,{children:(0,a.jsx)(s.S8,{stripe:N,options:{clientSecret:t||void 0,appearance:{theme:"stripe",variables:{colorPrimary:"#b45309"}}},children:(0,a.jsx)(T,{...e,clientSecret:t})})})]})}},80013:(e,t,r)=>{r.d(t,{J:()=>d});var n=r(76392),a=r(43210),i=r(78148),s=r(24224),o=r(4780);let l=(0,s.F)("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"),d=a.forwardRef(({className:e,...t},r)=>(0,n.jsx)(i.b,{ref:r,className:(0,o.cn)(l(),e),...t}));d.displayName=i.b.displayName},89667:(e,t,r)=>{r.d(t,{p:()=>s});var n=r(76392),a=r(43210),i=r(4780);let s=a.forwardRef(({className:e,type:t,...r},a)=>(0,n.jsx)("input",{type:t,className:(0,i.cn)("flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-base shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",e),ref:a,...r}));s.displayName="Input"},91821:(e,t,r)=>{r.d(t,{Fc:()=>l,TN:()=>d});var n=r(76392),a=r(43210),i=r(24224),s=r(4780);let o=(0,i.F)("relative w-full rounded-lg border px-4 py-3 text-sm [&>svg+div]:translate-y-[-3px] [&>svg]:absolute [&>svg]:left-4 [&>svg]:top-4 [&>svg]:text-foreground [&>svg~*]:pl-7",{variants:{variant:{default:"bg-background text-foreground",destructive:"border-destructive/50 text-destructive dark:border-destructive [&>svg]:text-destructive"}},defaultVariants:{variant:"default"}}),l=a.forwardRef(({className:e,variant:t,...r},a)=>(0,n.jsx)("div",{ref:a,role:"alert",className:(0,s.cn)(o({variant:t}),e),...r}));l.displayName="Alert",a.forwardRef(({className:e,...t},r)=>(0,n.jsx)("h5",{ref:r,className:(0,s.cn)("mb-1 font-medium leading-none tracking-tight",e),...t})).displayName="AlertTitle";let d=a.forwardRef(({className:e,...t},r)=>(0,n.jsx)("div",{ref:r,className:(0,s.cn)("text-sm [&_p]:leading-relaxed",e),...t}));d.displayName="AlertDescription"}};