(()=>{var e={};e.id=567,e.ids=[567],e.modules={3261:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>a});let a=(0,r(12907).registerClientReference)(function(){throw Error("Attempted to call the default export of \"/home/project/berenice-london/src/app/blog/[id]/page.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/home/project/berenice-london/src/app/blog/[id]/page.tsx","default")},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},4780:(e,t,r)=>{"use strict";r.d(t,{cn:()=>n});var a=r(49384),s=r(82348);function n(...e){return(0,s.QP)((0,a.$)(e))}},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},11273:(e,t,r)=>{"use strict";r.d(t,{A:()=>i,q:()=>n});var a=r(43210),s=r(60687);function n(e,t){let r=a.createContext(t),n=e=>{let{children:t,...n}=e,i=a.useMemo(()=>n,Object.values(n));return(0,s.jsx)(r.Provider,{value:i,children:t})};return n.displayName=e+"Provider",[n,function(s){let n=a.useContext(r);if(n)return n;if(void 0!==t)return t;throw Error(`\`${s}\` must be used within \`${e}\``)}]}function i(e,t=[]){let r=[],n=()=>{let t=r.map(e=>a.createContext(e));return function(r){let s=r?.[e]||t;return a.useMemo(()=>({[`__scope${e}`]:{...r,[e]:s}}),[r,s])}};return n.scopeName=e,[function(t,n){let i=a.createContext(n),o=r.length;r=[...r,n];let l=t=>{let{scope:r,children:n,...l}=t,c=r?.[e]?.[o]||i,d=a.useMemo(()=>l,Object.values(l));return(0,s.jsx)(c.Provider,{value:d,children:n})};return l.displayName=t+"Provider",[l,function(r,s){let l=s?.[e]?.[o]||i,c=a.useContext(l);if(c)return c;if(void 0!==n)return n;throw Error(`\`${r}\` must be used within \`${t}\``)}]},function(...e){let t=e[0];if(1===e.length)return t;let r=()=>{let r=e.map(e=>({useScope:e(),scopeName:e.scopeName}));return function(e){let s=r.reduce((t,{useScope:r,scopeName:a})=>{let s=r(e)[`__scope${a}`];return{...t,...s}},{});return a.useMemo(()=>({[`__scope${t.scopeName}`]:s}),[s])}};return r.scopeName=t.scopeName,r}(n,...t)]}},12720:(e,t,r)=>{"use strict";r.d(t,{eu:()=>k,q5:()=>A,BK:()=>C});var a=r(76392),s=r(43210),n=r(11273),i=r(13495),o=r(66156),l=r(14163),c=r(57379);function d(){return()=>{}}var u=r(60687),m="Avatar",[h,p]=(0,n.A)(m),[f,g]=h(m),x=s.forwardRef((e,t)=>{let{__scopeAvatar:r,...a}=e,[n,i]=s.useState("idle");return(0,u.jsx)(f,{scope:r,imageLoadingStatus:n,onImageLoadingStatusChange:i,children:(0,u.jsx)(l.sG.span,{...a,ref:t})})});x.displayName=m;var y="AvatarImage",v=s.forwardRef((e,t)=>{let{__scopeAvatar:r,src:a,onLoadingStatusChange:n=()=>{},...m}=e,h=g(y,r),p=function(e,{referrerPolicy:t,crossOrigin:r}){let a=(0,c.useSyncExternalStore)(d,()=>!0,()=>!1),n=s.useRef(null),i=a?(n.current||(n.current=new window.Image),n.current):null,[l,u]=s.useState(()=>j(i,e));return(0,o.N)(()=>{u(j(i,e))},[i,e]),(0,o.N)(()=>{let e=e=>()=>{u(e)};if(!i)return;let a=e("loaded"),s=e("error");return i.addEventListener("load",a),i.addEventListener("error",s),t&&(i.referrerPolicy=t),"string"==typeof r&&(i.crossOrigin=r),()=>{i.removeEventListener("load",a),i.removeEventListener("error",s)}},[i,r,t]),l}(a,m),f=(0,i.c)(e=>{n(e),h.onImageLoadingStatusChange(e)});return(0,o.N)(()=>{"idle"!==p&&f(p)},[p,f]),"loaded"===p?(0,u.jsx)(l.sG.img,{...m,ref:t,src:a}):null});v.displayName=y;var b="AvatarFallback",w=s.forwardRef((e,t)=>{let{__scopeAvatar:r,delayMs:a,...n}=e,i=g(b,r),[o,c]=s.useState(void 0===a);return s.useEffect(()=>{if(void 0!==a){let e=window.setTimeout(()=>c(!0),a);return()=>window.clearTimeout(e)}},[a]),o&&"loaded"!==i.imageLoadingStatus?(0,u.jsx)(l.sG.span,{...n,ref:t}):null});function j(e,t){return e?t?(e.src!==t&&(e.src=t),e.complete&&e.naturalWidth>0?"loaded":"loading"):"error":"idle"}w.displayName=b;var N=r(4780);let k=s.forwardRef(({className:e,...t},r)=>(0,a.jsx)(x,{ref:r,className:(0,N.cn)("relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full",e),...t}));k.displayName=x.displayName;let C=s.forwardRef(({className:e,...t},r)=>(0,a.jsx)(v,{ref:r,className:(0,N.cn)("aspect-square h-full w-full",e),...t}));C.displayName=v.displayName;let A=s.forwardRef(({className:e,...t},r)=>(0,a.jsx)(w,{ref:r,className:(0,N.cn)("flex h-full w-full items-center justify-center rounded-full bg-muted",e),...t}));A.displayName=w.displayName},13495:(e,t,r)=>{"use strict";r.d(t,{c:()=>s});var a=r(43210);function s(e){let t=a.useRef(e);return a.useEffect(()=>{t.current=e}),a.useMemo(()=>(...e)=>t.current?.(...e),[])}},14163:(e,t,r)=>{"use strict";r.d(t,{hO:()=>l,sG:()=>o});var a=r(43210),s=r(51215),n=r(8730),i=r(60687),o=["a","button","div","form","h2","h3","img","input","label","li","nav","ol","p","select","span","svg","ul"].reduce((e,t)=>{let r=(0,n.TL)(`Primitive.${t}`),s=a.forwardRef((e,a)=>{let{asChild:s,...n}=e;return"undefined"!=typeof window&&(window[Symbol.for("radix-ui")]=!0),(0,i.jsx)(s?r:t,{...n,ref:a})});return s.displayName=`Primitive.${t}`,{...e,[t]:s}},{});function l(e,t){e&&s.flushSync(()=>e.dispatchEvent(t))}},15036:(e,t,r)=>{"use strict";r.d(t,{A:()=>a});let a=(0,r(82614).A)("Clock",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]])},16189:(e,t,r)=>{"use strict";var a=r(65773);r.o(a,"useParams")&&r.d(t,{useParams:function(){return a.useParams}}),r.o(a,"useRouter")&&r.d(t,{useRouter:function(){return a.useRouter}})},19121:e=>{"use strict";e.exports=require("next/dist/server/app-render/action-async-storage.external.js")},20224:(e,t,r)=>{Promise.resolve().then(r.bind(r,95066))},24008:(e,t,r)=>{"use strict";r.d(t,{A:()=>s,t:()=>a});let a=[{id:"membership",name:"Membership",description:"Updates and benefits for our member community"},{id:"bespoke-wigs",name:"Bespoke Wigs & Toppers",description:"Custom-made hairpiece insights and stories"},{id:"ready-made",name:"Ready-Made Collection",description:"Our curated selection of premium wigs and toppers"},{id:"education",name:"Education & Training",description:"Professional courses and learning resources"},{id:"care-tips",name:"Care & Maintenance",description:"Expert tips for maintaining your hairpieces"},{id:"styling",name:"Styling Guide",description:"Creative styling ideas and techniques"}],s=[{id:"1",title:"The Ultimate Guide to Measuring Your Head for a Perfect Wig Fit",excerpt:"Learn the professional techniques our experts use to ensure your custom wig fits perfectly every time.",content:`Getting the perfect fit for your wig starts with accurate measurements. In this comprehensive guide, we'll walk you through the exact process our master craftspeople use at Berenice London.

## Why Accurate Measurements Matter

A properly fitted wig not only looks more natural but also feels more comfortable and secure. Poor measurements can lead to slipping, discomfort, or an unnatural appearance.

## Essential Tools You'll Need

- A flexible measuring tape
- A mirror
- A pen and paper
- A friend to help (optional but recommended)

## Step-by-Step Measurement Process

### 1. Circumference Measurement
Place the measuring tape around your head, about 1/8 inch above your ears and across your forehead. This gives you the overall head circumference.

### 2. Front to Back Measurement
Measure from your natural hairline at the forehead to the nape of your neck, going over the crown of your head.

### 3. Ear to Ear Measurement
Measure from the top of one ear, over the crown, to the top of the other ear.

### 4. Temple to Temple
Measure across your forehead from temple to temple, about 1 inch above your eyebrows.

## Tips for Accuracy

- Take measurements when your hair is flat against your head
- Don't pull the tape too tight or too loose
- Take each measurement twice to ensure accuracy
- Have someone help you for the most precise results

## What to Do With Your Measurements

Once you have all your measurements, our team will use these to create your custom pattern. We'll also discuss your lifestyle, styling preferences, and any specific needs you might have.

Remember, at Berenice London, we're here to guide you through every step of the process. Book a consultation with our experts to ensure your measurements are perfect and discuss your custom wig options.`,category:"education",author:"Sarah Mitchell",publishDate:"2024-01-15",readTime:5,tags:["measurements","fitting","custom-wigs","how-to"],featured:!0,imageUrl:"https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=800&h=400&fit=crop"},{id:"2",title:"Washing Your Hairpiece: A Complete Care Guide",excerpt:"Proper washing techniques to maintain the beauty and longevity of your premium hairpiece.",content:`Your hairpiece is an investment in your confidence and appearance. Proper care, especially washing, is essential to maintain its beauty and extend its lifespan.

## How Often to Wash

The frequency of washing depends on several factors:
- How often you wear your hairpiece
- Your lifestyle and activities
- Environmental factors
- Hair type (synthetic vs. human hair)

Generally, wash your hairpiece every 6-8 wears for human hair pieces, and every 10-12 wears for synthetic ones.

## What You'll Need

- Specialized wig shampoo (never use regular hair shampoo)
- Wig conditioner
- A wide-tooth comb
- A wig stand or mannequin head
- Clean towels
- Cool water

## Step-by-Step Washing Process

### Preparation
1. Gently brush your hairpiece to remove tangles
2. Fill a basin with cool water
3. Add a small amount of wig shampoo

### Washing
1. Immerse the hairpiece in the water
2. Gently swish for 2-3 minutes
3. Don't rub or scrub the hair
4. Rinse thoroughly with cool water

### Conditioning
1. Apply wig conditioner from mid-length to ends
2. Leave for 2-3 minutes
3. Rinse thoroughly

### Drying
1. Gently squeeze out excess water (don't wring)
2. Pat dry with a clean towel
3. Place on a wig stand to air dry
4. Never use heat unless the piece is specifically designed for it

## Pro Tips

- Always wash in cool water to prevent damage
- Use products specifically designed for wigs
- Be gentle throughout the process
- Store properly when not in use

Following these steps will help ensure your Berenice London hairpiece maintains its premium quality and appearance for years to come.`,category:"care-tips",author:"Emma Thompson",publishDate:"2024-01-10",readTime:4,tags:["hair-care","washing","maintenance","hairpiece"],featured:!0,imageUrl:"https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=800&h=400&fit=crop"},{id:"3",title:"New Premium Membership Benefits: What You Need to Know",excerpt:"Discover the exciting new benefits we've added to our Premium and Elite membership tiers.",content:`We're thrilled to announce exciting new benefits for our Premium and Elite members, effective immediately. These enhancements reflect our commitment to providing exceptional value and service to our community.

## New Premium Membership Benefits

### Monthly Styling Consultations
Premium members now receive monthly virtual styling consultations with our expert team. Perfect for seasonal updates or special occasion styling.

### Exclusive Product Access
Get early access to new arrivals and limited-edition pieces before they're available to the general public.

### Enhanced Discount Structure
- 15% off all services (increased from 10%)
- 20% off ready-made collection
- Free shipping on all orders

## Elite Membership Enhancements

### Personal Stylist Assignment
Each Elite member now gets a dedicated personal stylist for ongoing support and customized recommendations.

### Quarterly In-Person Sessions
Enjoy quarterly in-person styling and maintenance sessions at our London studio.

### VIP Event Access
Exclusive invitations to styling workshops, fashion shows, and member-only events.

## How to Upgrade

Current Basic members can upgrade to Premium or Elite at any time through their member dashboard. Contact our team for personalized upgrade recommendations based on your needs.

## Coming Soon

We're also working on:
- Mobile app for easier booking and communication
- Virtual reality wig try-on technology
- Expanded educational content library

Thank you for being part of the Berenice London community. Your membership makes all these improvements possible.`,category:"membership",author:"Berenice London Team",publishDate:"2024-01-08",readTime:3,tags:["membership","benefits","premium","elite"],featured:!1},{id:"4",title:"The Art of Bespoke Wig Creation: Behind the Scenes",excerpt:"Take a journey into our workshop and discover the meticulous craftsmanship behind every custom piece.",content:`Creating a bespoke wig is both an art and a science. Each piece that leaves our London workshop represents hundreds of hours of skilled craftsmanship and attention to detail.

## The Design Process

Every bespoke piece begins with a comprehensive consultation. We discuss:
- Your lifestyle and daily routine
- Color preferences and skin tone
- Desired length and style
- Specific requirements or concerns

## Hair Selection

We source only the finest materials:
- Premium European hair for the most natural look
- Ethically sourced materials
- Multiple color matching for perfect blends
- Quality testing for durability and appearance

## The Crafting Process

### Foundation Creation
The wig cap is hand-crafted to your exact measurements, ensuring a perfect fit that's both comfortable and secure.

### Hair Insertion
Each hair is individually hand-tied using traditional techniques passed down through generations of master craftspeople.

### Styling and Finishing
The final styling brings your vision to life, with attention to natural growth patterns and movement.

## Quality Assurance

Before delivery, every piece undergoes rigorous quality checks:
- Fit verification
- Color accuracy
- Movement and naturalness
- Durability testing

## The Result

The result is a truly unique piece that not only meets but exceeds your expectations. A bespoke wig from Berenice London isn't just a hairpiece—it's a transformation that restores confidence and enhances your natural beauty.

Ready to begin your bespoke journey? Book a consultation with our master craftspeople today.`,category:"bespoke-wigs",author:"Master Craftsman James Wilson",publishDate:"2024-01-05",readTime:6,tags:["bespoke","craftsmanship","custom-wigs","process"],featured:!0,imageUrl:"https://images.unsplash.com/photo-1562322140-8baeececf3df?w=800&h=400&fit=crop"},{id:"5",title:"Spring 2024 Ready-Made Collection Preview",excerpt:"Get an exclusive first look at our stunning new ready-made pieces for the upcoming season.",content:`Spring brings new beginnings, and our Spring 2024 Ready-Made Collection embodies fresh sophistication and effortless elegance.

## Collection Highlights

### Natural Textures
This season emphasizes natural movement and texture, with pieces that complement rather than mask your natural beauty.

### Color Palette
- Warm honey blondes
- Rich chocolate browns
- Sophisticated salt-and-pepper grays
- Bold copper reds for the adventurous

### Trending Styles

#### The "London Bob"
A chic, shoulder-length cut with subtle layers that works for any occasion.

#### "Garden Party Waves"
Romantic, flowing waves perfect for spring and summer events.

#### "Executive Elegance"
Professional styles that command respect in any boardroom.

## Technical Innovations

### Improved Cap Construction
Our new cap design offers:
- Better breathability for warmer weather
- Enhanced comfort for all-day wear
- More secure fit with adjustable sizing

### Advanced Hair Processing
New treatment methods ensure:
- Longer-lasting color
- Improved texture retention
- Enhanced shine and movement

## Availability

The collection launches February 15th, with Premium and Elite members getting early access starting February 1st.

Each piece comes with:
- Professional styling guide
- Care instruction kit
- 6-month warranty
- Complimentary initial styling session

Visit our showroom or book a virtual consultation to see these beautiful pieces and find your perfect match for spring.`,category:"ready-made",author:"Design Team Lead Maria Rodriguez",publishDate:"2024-01-03",readTime:4,tags:["spring-2024","ready-made","collection","new-arrivals"],featured:!1,imageUrl:"https://images.unsplash.com/photo-1594736797933-d0e501ba2fe0?w=800&h=400&fit=crop"},{id:"6",title:"5 Essential Styling Tools Every Wig Owner Should Have",excerpt:"Build your styling toolkit with these professional-grade tools recommended by our expert stylists.",content:`The right tools make all the difference in maintaining and styling your wig. Here are the five essential items every wig owner should have in their toolkit.

## 1. Wide-Tooth Comb

### Why You Need It
A wide-tooth comb is gentle on wig fibers and prevents unnecessary tension that can cause shedding or damage.

### How to Use
- Always start combing from the ends
- Work your way up to the roots gradually
- Use gentle, downward motions

### Our Recommendation
Look for combs made from seamless materials to prevent snagging.

## 2. Wig Brush with Ball-Tipped Bristles

### Benefits
- Reduces static and flyaways
- Distributes natural oils evenly
- Gentle on both synthetic and human hair

### Best Practices
- Brush when the wig is dry
- Use long, smooth strokes
- Clean your brush regularly

## 3. Wig Stand or Mannequin Head

### Essential for
- Proper storage between wears
- Styling and maintenance
- Air drying after washing

### Storage Tips
- Choose a stand that matches your head size
- Store in a cool, dry place
- Cover with a silk scarf to prevent dust

## 4. Heat Protectant Spray

### When to Use
Before any heat styling on human hair wigs (never use heat on synthetic unless specifically designed for it).

### Protection Benefits
- Prevents heat damage
- Maintains hair integrity
- Extends wig lifespan

## 5. Specialized Wig Shampoo and Conditioner

### Why Regular Products Don't Work
Regular hair products can:
- Strip color from wig fibers
- Build up on the cap
- Reduce the wig's lifespan

### Choosing the Right Products
- Look for sulfate-free formulas
- Choose products designed for your wig type
- Consider professional-grade options

## Bonus Tool: Silk Scarf

### Multiple Uses
- Sleeping protection
- Storage covering
- Gentle drying aid

## Investment in Longevity

Quality tools are an investment in your wig's longevity and appearance. At Berenice London, we offer a complete styling toolkit designed specifically for our pieces.

Ready to upgrade your wig care routine? Contact our team for personalized tool recommendations based on your specific needs and wig type.`,category:"styling",author:"Senior Stylist Rachel Green",publishDate:"2023-12-28",readTime:5,tags:["styling-tools","wig-care","maintenance","professional-tips"],featured:!1}]},26622:(e,t,r)=>{"use strict";r.d(t,{A:()=>a});let a=(0,r(82614).A)("Calendar",[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}]])},26838:(e,t,r)=>{"use strict";r.d(t,{A:()=>a});let a=(0,r(82614).A)("Heart",[["path",{d:"M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z",key:"c3ymky"}]])},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},29523:(e,t,r)=>{"use strict";r.d(t,{$:()=>c,r:()=>l});var a=r(76392),s=r(43210),n=r(8730),i=r(24224),o=r(4780);let l=(0,i.F)("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",{variants:{variant:{default:"bg-primary text-primary-foreground shadow hover:bg-primary/90",destructive:"bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",outline:"border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",secondary:"bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",ghost:"hover:bg-accent hover:text-accent-foreground",link:"text-primary underline-offset-4 hover:underline"},size:{default:"h-9 px-4 py-2",sm:"h-8 rounded-md px-3 text-xs",lg:"h-10 rounded-md px-8",icon:"h-9 w-9"}},defaultVariants:{variant:"default",size:"default"}}),c=s.forwardRef(({className:e,variant:t,size:r,asChild:s=!1,...i},c)=>{let d=s?n.DX:"button";return(0,a.jsx)(d,{className:(0,o.cn)(l({variant:t,size:r,className:e})),ref:c,...i})});c.displayName="Button"},33873:e=>{"use strict";e.exports=require("path")},34729:(e,t,r)=>{"use strict";r.d(t,{T:()=>i});var a=r(76392),s=r(43210),n=r(4780);let i=s.forwardRef(({className:e,...t},r)=>(0,a.jsx)("textarea",{className:(0,n.cn)("flex min-h-[60px] w-full rounded-md border border-input bg-transparent px-3 py-2 text-base shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",e),ref:r,...t}));i.displayName="Textarea"},35950:(e,t,r)=>{"use strict";r.d(t,{w:()=>o});var a=r(76392),s=r(43210),n=r(62369),i=r(4780);let o=s.forwardRef(({className:e,orientation:t="horizontal",decorative:r=!0,...s},o)=>(0,a.jsx)(n.b,{ref:o,decorative:r,orientation:t,className:(0,i.cn)("shrink-0 bg-border","horizontal"===t?"h-[1px] w-full":"h-full w-[1px]",e),...s}));o.displayName=n.b.displayName},44493:(e,t,r)=>{"use strict";r.d(t,{BT:()=>c,Wu:()=>d,ZB:()=>l,Zp:()=>i,aR:()=>o});var a=r(76392),s=r(43210),n=r(4780);let i=s.forwardRef(({className:e,...t},r)=>(0,a.jsx)("div",{ref:r,className:(0,n.cn)("rounded-xl border bg-card text-card-foreground shadow",e),...t}));i.displayName="Card";let o=s.forwardRef(({className:e,...t},r)=>(0,a.jsx)("div",{ref:r,className:(0,n.cn)("flex flex-col space-y-1.5 p-6",e),...t}));o.displayName="CardHeader";let l=s.forwardRef(({className:e,...t},r)=>(0,a.jsx)("div",{ref:r,className:(0,n.cn)("font-semibold leading-none tracking-tight",e),...t}));l.displayName="CardTitle";let c=s.forwardRef(({className:e,...t},r)=>(0,a.jsx)("div",{ref:r,className:(0,n.cn)("text-sm text-muted-foreground",e),...t}));c.displayName="CardDescription";let d=s.forwardRef(({className:e,...t},r)=>(0,a.jsx)("div",{ref:r,className:(0,n.cn)("p-6 pt-0",e),...t}));d.displayName="CardContent",s.forwardRef(({className:e,...t},r)=>(0,a.jsx)("div",{ref:r,className:(0,n.cn)("flex items-center p-6 pt-0",e),...t})).displayName="CardFooter"},53332:(e,t,r)=>{"use strict";var a=r(43210),s="function"==typeof Object.is?Object.is:function(e,t){return e===t&&(0!==e||1/e==1/t)||e!=e&&t!=t},n=a.useState,i=a.useEffect,o=a.useLayoutEffect,l=a.useDebugValue;function c(e){var t=e.getSnapshot;e=e.value;try{var r=t();return!s(e,r)}catch(e){return!0}}var d="undefined"==typeof window||void 0===window.document||void 0===window.document.createElement?function(e,t){return t()}:function(e,t){var r=t(),a=n({inst:{value:r,getSnapshot:t}}),s=a[0].inst,d=a[1];return o(function(){s.value=r,s.getSnapshot=t,c(s)&&d({inst:s})},[e,r,t]),i(function(){return c(s)&&d({inst:s}),e(function(){c(s)&&d({inst:s})})},[e]),l(r),r};t.useSyncExternalStore=void 0!==a.useSyncExternalStore?a.useSyncExternalStore:d},55817:(e,t,r)=>{"use strict";r.d(t,{A:()=>a});let a=(0,r(82614).A)("ArrowLeft",[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]])},57379:(e,t,r)=>{"use strict";e.exports=r(53332)},58595:(e,t,r)=>{"use strict";r.d(t,{A:()=>a});let a=(0,r(82614).A)("User",[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]])},62369:(e,t,r)=>{"use strict";r.d(t,{b:()=>c});var a=r(43210),s=r(14163),n=r(60687),i="horizontal",o=["horizontal","vertical"],l=a.forwardRef((e,t)=>{var r;let{decorative:a,orientation:l=i,...c}=e,d=(r=l,o.includes(r))?l:i;return(0,n.jsx)(s.sG.div,{"data-orientation":d,...a?{role:"none"}:{"aria-orientation":"vertical"===d?d:void 0,role:"separator"},...c,ref:t})});l.displayName="Separator";var c=l},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},66156:(e,t,r)=>{"use strict";r.d(t,{N:()=>s});var a=r(43210),s=globalThis?.document?a.useLayoutEffect:()=>{}},74158:(e,t,r)=>{"use strict";r.d(t,{A:()=>a});let a=(0,r(82614).A)("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]])},78148:(e,t,r)=>{"use strict";r.d(t,{b:()=>o});var a=r(43210),s=r(14163),n=r(60687),i=a.forwardRef((e,t)=>(0,n.jsx)(s.sG.label,{...e,ref:t,onMouseDown:t=>{t.target.closest("button, input, select, textarea")||(e.onMouseDown?.(t),!t.defaultPrevented&&t.detail>1&&t.preventDefault())}}));i.displayName="Label";var o=i},80013:(e,t,r)=>{"use strict";r.d(t,{J:()=>c});var a=r(76392),s=r(43210),n=r(78148),i=r(24224),o=r(4780);let l=(0,i.F)("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"),c=s.forwardRef(({className:e,...t},r)=>(0,a.jsx)(n.b,{ref:r,className:(0,o.cn)(l(),e),...t}));c.displayName=n.b.displayName},89667:(e,t,r)=>{"use strict";r.d(t,{p:()=>i});var a=r(76392),s=r(43210),n=r(4780);let i=s.forwardRef(({className:e,type:t,...r},s)=>(0,a.jsx)("input",{type:t,className:(0,n.cn)("flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-base shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",e),ref:s,...r}));i.displayName="Input"},90848:(e,t,r)=>{Promise.resolve().then(r.bind(r,3261))},95066:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>M});var a=r(76392),s=r(43210),n=r(16189),i=r(44493),o=r(29523),l=r(96834),c=r(12720),d=r(89667),u=r(80013),m=r(34729),h=r(35950),p=r(24008),f=r(97034),g=r(55817),x=r(93257),y=r(58595),v=r(26622),b=r(15036),w=r(26838),j=r(82614);let N=(0,j.A)("Facebook",[["path",{d:"M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z",key:"1jg4f8"}]]),k=(0,j.A)("Twitter",[["path",{d:"M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z",key:"pff0z6"}]]),C=(0,j.A)("Linkedin",[["path",{d:"M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z",key:"c2jq9f"}],["rect",{width:"4",height:"12",x:"2",y:"9",key:"mk3on5"}],["circle",{cx:"4",cy:"4",r:"2",key:"bt5ra8"}]]),A=(0,j.A)("Copy",[["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]]),S=(0,j.A)("MessageCircle",[["path",{d:"M7.9 20A9 9 0 1 0 4 16.1L2 22Z",key:"vv11sd"}]]);var P=r(74158),E=r(85814),T=r.n(E);let R=[{id:"1",author:"Emma Thompson",email:"emma@example.com",content:"This was incredibly helpful! I had no idea about the proper measurement techniques. Thank you for sharing this detailed guide.",date:"2024-01-16",replies:[{id:"1-1",author:"Sarah Mitchell",email:"sarah@berenice.com",content:"Thank you Emma! We're so glad you found it helpful. If you need any personalized guidance, feel free to book a consultation.",date:"2024-01-16",isAuthor:!0}]},{id:"2",author:"Rachel Green",email:"rachel@example.com",content:"The step-by-step process is exactly what I needed. I've been struggling with getting the right fit for months.",date:"2024-01-17"}];function M(){let e;(0,n.useParams)();let[t,r]=(0,s.useState)(null),[j,E]=(0,s.useState)([]),[M,B]=(0,s.useState)(R),[W,L]=(0,s.useState)({author:"",email:"",content:""}),[z,q]=(0,s.useState)(!1),[D,$]=(0,s.useState)(42);if(!t)return(0,a.jsx)("div",{className:"min-h-screen bg-gradient-to-br from-stone-50 to-amber-50 flex items-center justify-center",children:(0,a.jsxs)("div",{className:"text-center",children:[(0,a.jsx)(f.A,{className:"h-16 w-16 text-gray-400 mx-auto mb-4"}),(0,a.jsx)("h1",{className:"text-2xl font-bold text-gray-900 mb-2",children:"Post Not Found"}),(0,a.jsx)("p",{className:"text-gray-600 mb-6",children:"The blog post you're looking for doesn't exist."}),(0,a.jsx)(T(),{href:"/blog",children:(0,a.jsxs)(o.$,{className:"bg-amber-700 hover:bg-amber-800",children:[(0,a.jsx)(g.A,{className:"h-4 w-4 mr-2"}),"Back to Blog"]})})]})});let G=e=>new Date(e).toLocaleDateString("en-US",{year:"numeric",month:"long",day:"numeric"}),I=e=>{let r=window.location.href,a=t.title,s="";switch(e){case"facebook":s=`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(r)}`;break;case"twitter":s=`https://twitter.com/intent/tweet?url=${encodeURIComponent(r)}&text=${encodeURIComponent(a)}`;break;case"linkedin":s=`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(r)}`;break;case"copy":navigator.clipboard.writeText(r);return}s&&window.open(s,"_blank","width=600,height=400")};return(0,a.jsxs)("div",{className:"min-h-screen bg-gradient-to-br from-stone-50 to-amber-50",children:[(0,a.jsx)("nav",{className:"bg-white/80 backdrop-blur-md border-b border-stone-200 sticky top-0 z-50",children:(0,a.jsx)("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:(0,a.jsxs)("div",{className:"flex justify-between items-center h-16",children:[(0,a.jsxs)(T(),{href:"/",className:"flex items-center gap-2",children:[(0,a.jsx)(x.A,{className:"h-8 w-8 text-amber-700"}),(0,a.jsx)("h1",{className:"text-2xl font-bold text-stone-800",children:"Berenice London"})]}),(0,a.jsx)(T(),{href:"/blog",children:(0,a.jsxs)(o.$,{variant:"ghost",className:"flex items-center gap-2",children:[(0,a.jsx)(g.A,{className:"h-4 w-4"}),"Back to Blog"]})})]})})}),(0,a.jsxs)("div",{className:"max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12",children:[(0,a.jsxs)("div",{className:"mb-8",children:[(0,a.jsx)(l.E,{className:"mb-4",children:(e=t.category,p.t.find(t=>t.id===e)?.name||e)}),(0,a.jsx)("h1",{className:"text-4xl md:text-5xl font-bold text-stone-800 mb-6 leading-tight",children:t.title}),(0,a.jsx)("p",{className:"text-xl text-stone-600 mb-8",children:t.excerpt}),(0,a.jsxs)("div",{className:"flex items-center justify-between flex-wrap gap-4",children:[(0,a.jsxs)("div",{className:"flex items-center gap-6 text-sm text-gray-600",children:[(0,a.jsxs)("div",{className:"flex items-center gap-2",children:[(0,a.jsx)(y.A,{className:"h-4 w-4"}),t.author]}),(0,a.jsxs)("div",{className:"flex items-center gap-2",children:[(0,a.jsx)(v.A,{className:"h-4 w-4"}),G(t.publishDate)]}),(0,a.jsxs)("div",{className:"flex items-center gap-2",children:[(0,a.jsx)(b.A,{className:"h-4 w-4"}),t.readTime," min read"]})]}),(0,a.jsxs)("div",{className:"flex items-center gap-2",children:[(0,a.jsxs)(o.$,{size:"sm",variant:z?"default":"outline",onClick:()=>{q(!z),$(e=>z?e-1:e+1)},className:z?"bg-red-500 hover:bg-red-600":"",children:[(0,a.jsx)(w.A,{className:`h-4 w-4 mr-1 ${z?"fill-current":""}`}),D]}),(0,a.jsx)(o.$,{size:"sm",variant:"outline",onClick:()=>I("facebook"),children:(0,a.jsx)(N,{className:"h-4 w-4"})}),(0,a.jsx)(o.$,{size:"sm",variant:"outline",onClick:()=>I("twitter"),children:(0,a.jsx)(k,{className:"h-4 w-4"})}),(0,a.jsx)(o.$,{size:"sm",variant:"outline",onClick:()=>I("linkedin"),children:(0,a.jsx)(C,{className:"h-4 w-4"})}),(0,a.jsx)(o.$,{size:"sm",variant:"outline",onClick:()=>I("copy"),children:(0,a.jsx)(A,{className:"h-4 w-4"})})]})]})]}),t.imageUrl&&(0,a.jsx)("div",{className:"mb-8",children:(0,a.jsx)("img",{src:t.imageUrl,alt:t.title,className:"w-full h-64 md:h-96 object-cover rounded-lg shadow-lg"})}),(0,a.jsx)("div",{className:"prose prose-lg max-w-none mb-12",children:(0,a.jsx)("div",{className:"bg-white rounded-lg p-8 shadow-sm",children:t.content.split("\n").map((e,t)=>e.startsWith("## ")?(0,a.jsx)("h2",{className:"text-2xl font-bold text-stone-800 mt-8 mb-4",children:e.slice(3)},t):e.startsWith("### ")?(0,a.jsx)("h3",{className:"text-xl font-semibold text-stone-800 mt-6 mb-3",children:e.slice(4)},t):""===e.trim()?(0,a.jsx)("br",{},t):(0,a.jsx)("p",{className:"text-stone-700 leading-relaxed mb-4",children:e},t))})}),(0,a.jsxs)("div",{className:"mb-8",children:[(0,a.jsx)("h3",{className:"text-lg font-semibold mb-4",children:"Tags"}),(0,a.jsx)("div",{className:"flex flex-wrap gap-2",children:t.tags.map(e=>(0,a.jsxs)(l.E,{variant:"outline",children:["#",e]},e))})]}),(0,a.jsx)(h.w,{className:"my-8"}),(0,a.jsxs)("div",{className:"mb-12",children:[(0,a.jsxs)("h3",{className:"text-2xl font-bold text-stone-800 mb-6 flex items-center gap-2",children:[(0,a.jsx)(S,{className:"h-6 w-6"}),"Comments (",M.length,")"]}),(0,a.jsxs)(i.Zp,{className:"mb-8",children:[(0,a.jsx)(i.aR,{children:(0,a.jsx)(i.ZB,{children:"Leave a Comment"})}),(0,a.jsx)(i.Wu,{children:(0,a.jsxs)("form",{onSubmit:e=>{if(e.preventDefault(),!W.author||!W.email||!W.content)return;let t={id:Date.now().toString(),author:W.author,email:W.email,content:W.content,date:new Date().toISOString().split("T")[0]};B(e=>[...e,t]),L({author:"",email:"",content:""})},className:"space-y-4",children:[(0,a.jsxs)("div",{className:"grid md:grid-cols-2 gap-4",children:[(0,a.jsxs)("div",{children:[(0,a.jsx)(u.J,{htmlFor:"name",children:"Name"}),(0,a.jsx)(d.p,{id:"name",value:W.author,onChange:e=>L(t=>({...t,author:e.target.value})),required:!0})]}),(0,a.jsxs)("div",{children:[(0,a.jsx)(u.J,{htmlFor:"email",children:"Email"}),(0,a.jsx)(d.p,{id:"email",type:"email",value:W.email,onChange:e=>L(t=>({...t,email:e.target.value})),required:!0})]})]}),(0,a.jsxs)("div",{children:[(0,a.jsx)(u.J,{htmlFor:"comment",children:"Comment"}),(0,a.jsx)(m.T,{id:"comment",rows:4,value:W.content,onChange:e=>L(t=>({...t,content:e.target.value})),required:!0})]}),(0,a.jsx)(o.$,{type:"submit",className:"bg-amber-700 hover:bg-amber-800",children:"Post Comment"})]})})]}),(0,a.jsx)("div",{className:"space-y-6",children:M.map(e=>(0,a.jsx)(i.Zp,{children:(0,a.jsx)(i.Wu,{className:"pt-6",children:(0,a.jsxs)("div",{className:"flex items-start gap-4",children:[(0,a.jsx)(c.eu,{children:(0,a.jsx)(c.q5,{children:e.author.split(" ").map(e=>e[0]).join("")})}),(0,a.jsxs)("div",{className:"flex-1",children:[(0,a.jsxs)("div",{className:"flex items-center gap-2 mb-2",children:[(0,a.jsx)("span",{className:"font-medium",children:e.author}),e.isAuthor&&(0,a.jsx)(l.E,{variant:"secondary",className:"text-xs",children:"Author"}),(0,a.jsx)("span",{className:"text-sm text-gray-500",children:G(e.date)})]}),(0,a.jsx)("p",{className:"text-stone-700",children:e.content}),e.replies&&(0,a.jsx)("div",{className:"ml-8 mt-4 space-y-4",children:e.replies.map(e=>(0,a.jsxs)("div",{className:"flex items-start gap-4",children:[(0,a.jsx)(c.eu,{className:"h-8 w-8",children:(0,a.jsx)(c.q5,{className:"text-xs",children:e.author.split(" ").map(e=>e[0]).join("")})}),(0,a.jsxs)("div",{className:"flex-1",children:[(0,a.jsxs)("div",{className:"flex items-center gap-2 mb-2",children:[(0,a.jsx)("span",{className:"font-medium text-sm",children:e.author}),e.isAuthor&&(0,a.jsx)(l.E,{variant:"secondary",className:"text-xs",children:"Author"}),(0,a.jsx)("span",{className:"text-xs text-gray-500",children:G(e.date)})]}),(0,a.jsx)("p",{className:"text-stone-700 text-sm",children:e.content})]})]},e.id))})]})]})})},e.id))})]}),j.length>0&&(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(h.w,{className:"my-8"}),(0,a.jsxs)("div",{children:[(0,a.jsx)("h3",{className:"text-2xl font-bold text-stone-800 mb-6",children:"Related Posts"}),(0,a.jsx)("div",{className:"grid md:grid-cols-3 gap-6",children:j.map(e=>(0,a.jsxs)(i.Zp,{className:"hover:shadow-lg transition-shadow",children:[e.imageUrl&&(0,a.jsx)("div",{className:"aspect-video overflow-hidden rounded-t-lg",children:(0,a.jsx)("img",{src:e.imageUrl,alt:e.title,className:"w-full h-full object-cover"})}),(0,a.jsxs)(i.aR,{children:[(0,a.jsx)(i.ZB,{className:"text-lg line-clamp-2",children:e.title}),(0,a.jsx)(i.BT,{className:"line-clamp-2",children:e.excerpt})]}),(0,a.jsx)(i.Wu,{children:(0,a.jsx)(T(),{href:`/blog/${e.id}`,children:(0,a.jsxs)(o.$,{variant:"ghost",className:"w-full justify-between",children:["Read More",(0,a.jsx)(P.A,{className:"h-4 w-4"})]})})})]},e.id))})]})]}),(0,a.jsx)("div",{className:"mt-12",children:(0,a.jsx)(i.Zp,{className:"bg-amber-50 border-amber-200",children:(0,a.jsxs)(i.Wu,{className:"text-center py-8",children:[(0,a.jsx)("h3",{className:"text-xl font-bold text-stone-800 mb-4",children:"Need Personal Guidance?"}),(0,a.jsx)("p",{className:"text-stone-600 mb-6",children:"Our expert team is here to help you achieve your perfect hair solution."}),(0,a.jsx)(T(),{href:"/booking",children:(0,a.jsx)(o.$,{className:"bg-amber-700 hover:bg-amber-800",children:"Book Your Consultation"})})]})})})]})]})}},96834:(e,t,r)=>{"use strict";r.d(t,{E:()=>o});var a=r(76392);r(43210);var s=r(24224),n=r(4780);let i=(0,s.F)("inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",{variants:{variant:{default:"border-transparent bg-primary text-primary-foreground shadow hover:bg-primary/80",secondary:"border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",destructive:"border-transparent bg-destructive text-destructive-foreground shadow hover:bg-destructive/80",outline:"text-foreground"}},defaultVariants:{variant:"default"}});function o({className:e,variant:t,...r}){return(0,a.jsx)("div",{className:(0,n.cn)(i({variant:t}),e),...r})}},96996:(e,t,r)=>{"use strict";r.r(t),r.d(t,{GlobalError:()=>i.a,__next_app__:()=>u,pages:()=>d,routeModule:()=>m,tree:()=>c});var a=r(65239),s=r(48088),n=r(88170),i=r.n(n),o=r(30893),l={};for(let e in o)0>["default","tree","pages","GlobalError","__next_app__","routeModule"].indexOf(e)&&(l[e]=()=>o[e]);r.d(t,l);let c={children:["",{children:["blog",{children:["[id]",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(r.bind(r,3261)),"/home/project/berenice-london/src/app/blog/[id]/page.tsx"]}]},{}]},{}]},{layout:[()=>Promise.resolve().then(r.bind(r,94431)),"/home/project/berenice-london/src/app/layout.tsx"],"not-found":[()=>Promise.resolve().then(r.t.bind(r,57398,23)),"next/dist/client/components/not-found-error"],forbidden:[()=>Promise.resolve().then(r.t.bind(r,89999,23)),"next/dist/client/components/forbidden-error"],unauthorized:[()=>Promise.resolve().then(r.t.bind(r,65284,23)),"next/dist/client/components/unauthorized-error"]}]}.children,d=["/home/project/berenice-london/src/app/blog/[id]/page.tsx"],u={require:r,loadChunk:()=>Promise.resolve()},m=new a.AppPageRouteModule({definition:{kind:s.RouteKind.APP_PAGE,page:"/blog/[id]/page",pathname:"/blog/[id]",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:c}})},97034:(e,t,r)=>{"use strict";r.d(t,{A:()=>a});let a=(0,r(82614).A)("BookOpen",[["path",{d:"M12 7v14",key:"1akyts"}],["path",{d:"M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z",key:"ruj8y"}]])}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[447,721,47,507],()=>r(96996));module.exports=a})();