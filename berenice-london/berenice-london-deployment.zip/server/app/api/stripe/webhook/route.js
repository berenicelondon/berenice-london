(()=>{var e={};e.id=287,e.ids=[287],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},28354:e=>{"use strict";e.exports=require("util")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},53775:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>T,routeModule:()=>w,serverHooks:()=>$,workAsyncStorage:()=>E,workUnitAsyncStorage:()=>k});var n={};r.r(n),r.d(n,{GET:()=>v,POST:()=>x});var i=r(96559),o=r(48088),a=r(37719),s=r(32190),d=r(96706);class c{getTemplate(e,t){switch(e){case"booking_confirmation":return{subject:`Booking Confirmation - ${t.bookingReference}`,htmlContent:this.generateBookingConfirmationHTML(t),textContent:this.generateBookingConfirmationText(t)};case"booking_reminder":return{subject:`Appointment Reminder - Tomorrow at ${t.appointmentTime}`,htmlContent:this.generateBookingReminderHTML(t),textContent:this.generateBookingReminderText(t)};case"membership_welcome":return{subject:`Welcome to Berenice London - ${t.membershipTier} Membership`,htmlContent:this.generateMembershipWelcomeHTML(t),textContent:this.generateMembershipWelcomeText(t)};case"membership_upgrade":return{subject:`Membership Upgraded - Welcome to ${t.newTier}`,htmlContent:this.generateMembershipUpgradeHTML(t),textContent:this.generateMembershipUpgradeText(t)};case"payment_confirmation":return{subject:`Payment Received - \xa3${t.amount}`,htmlContent:this.generatePaymentConfirmationHTML(t),textContent:this.generatePaymentConfirmationText(t)};default:throw Error(`Unknown email template type: ${e}`)}}generateBookingConfirmationHTML(e){return`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #b45309, #d97706); color: white; padding: 30px; text-align: center; }
            .content { background: #fff; padding: 30px; border: 1px solid #e5e7eb; }
            .footer { background: #f9fafb; padding: 20px; text-align: center; font-size: 14px; color: #6b7280; }
            .button { display: inline-block; background: #d97706; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 10px 0; }
            .details { background: #fef3c7; padding: 20px; border-radius: 8px; margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Booking Confirmed</h1>
              <p>Thank you for choosing Berenice London</p>
            </div>
            <div class="content">
              <p>Dear ${e.userName},</p>
              <p>Your appointment has been successfully confirmed. We're excited to help you achieve your perfect hair solution.</p>

              <div class="details">
                <h3>Appointment Details</h3>
                <p><strong>Booking Reference:</strong> ${e.bookingReference}</p>
                <p><strong>Service:</strong> ${e.serviceName}</p>
                <p><strong>Date:</strong> ${e.appointmentDate}</p>
                <p><strong>Time:</strong> ${e.appointmentTime}</p>
                <p><strong>Duration:</strong> ${e.duration}</p>
                <p><strong>Location:</strong> ${e.location}</p>
                <p><strong>Total:</strong> \xa3${e.amount}</p>
              </div>

              <h3>What to Expect</h3>
              <ul>
                <li>Arrive 10 minutes early for check-in</li>
                <li>Bring any reference photos or inspiration</li>
                <li>Wear comfortable clothing</li>
                <li>Come with clean, dry hair if possible</li>
              </ul>

              <h3>Need to Make Changes?</h3>
              <p>If you need to reschedule or cancel, please contact us at least 24 hours in advance.</p>

              <div style="text-align: center; margin: 30px 0;">
                <a href="${this.baseUrl}/my-bookings" class="button">View My Bookings</a>
              </div>
            </div>
            <div class="footer">
              <p>Berenice London | Expert Hair Solutions</p>
              <p>Studio Address | London | Phone: 020 XXXX XXXX</p>
            </div>
          </div>
        </body>
      </html>
    `}generateBookingConfirmationText(e){return`
      BOOKING CONFIRMED - BERENICE LONDON

      Dear ${e.userName},

      Your appointment has been successfully confirmed.

      APPOINTMENT DETAILS:
      Booking Reference: ${e.bookingReference}
      Service: ${e.serviceName}
      Date: ${e.appointmentDate}
      Time: ${e.appointmentTime}
      Duration: ${e.duration}
      Location: ${e.location}
      Total: \xa3${e.amount}

      WHAT TO EXPECT:
      • Arrive 10 minutes early for check-in
      • Bring any reference photos or inspiration
      • Wear comfortable clothing
      • Come with clean, dry hair if possible

      Need to make changes? Contact us at least 24 hours in advance.

      View your bookings: ${this.baseUrl}/my-bookings

      Thank you for choosing Berenice London!
    `}generateBookingReminderHTML(e){return`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #b45309, #d97706); color: white; padding: 30px; text-align: center; }
            .content { background: #fff; padding: 30px; border: 1px solid #e5e7eb; }
            .reminder-box { background: #fef3c7; padding: 20px; border-radius: 8px; text-align: center; margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Appointment Reminder</h1>
            </div>
            <div class="content">
              <p>Dear ${e.userName},</p>

              <div class="reminder-box">
                <h2>Your appointment is tomorrow!</h2>
                <p><strong>${e.serviceName}</strong></p>
                <p>${e.appointmentDate} at ${e.appointmentTime}</p>
              </div>

              <p>We're looking forward to seeing you tomorrow. Please remember to:</p>
              <ul>
                <li>Arrive 10 minutes early</li>
                <li>Bring any inspiration photos</li>
                <li>Wear comfortable clothing</li>
              </ul>

              <p>If you need to make any last-minute changes, please call us as soon as possible.</p>
            </div>
          </div>
        </body>
      </html>
    `}generateBookingReminderText(e){return`
      APPOINTMENT REMINDER - BERENICE LONDON

      Dear ${e.userName},

      Your appointment is tomorrow!

      ${e.serviceName}
      ${e.appointmentDate} at ${e.appointmentTime}

      Please remember to:
      • Arrive 10 minutes early
      • Bring any inspiration photos
      • Wear comfortable clothing

      See you tomorrow!
    `}generateMembershipWelcomeHTML(e){return`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #b45309, #d97706); color: white; padding: 30px; text-align: center; }
            .content { background: #fff; padding: 30px; border: 1px solid #e5e7eb; }
            .benefits { background: #fef3c7; padding: 20px; border-radius: 8px; margin: 20px 0; }
            .button { display: inline-block; background: #d97706; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 10px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Welcome to Berenice London!</h1>
              <p>Your ${e.membershipTier} membership is now active</p>
            </div>
            <div class="content">
              <p>Dear ${e.userName},</p>
              <p>Welcome to the Berenice London family! We're thrilled to have you as a ${e.membershipTier} member.</p>

              <div class="benefits">
                <h3>Your ${e.membershipTier} Benefits Include:</h3>
                ${this.getMembershipBenefitsHTML(e.membershipTier)}
              </div>

              <h3>Getting Started</h3>
              <p>Your member dashboard is ready for you with exclusive content, priority booking, and personalized recommendations.</p>

              <div style="text-align: center; margin: 30px 0;">
                <a href="${this.baseUrl}/dashboard" class="button">Access Your Dashboard</a>
              </div>
            </div>
          </div>
        </body>
      </html>
    `}generateMembershipWelcomeText(e){return`
      WELCOME TO BERENICE LONDON!

      Dear ${e.userName},

      Your ${e.membershipTier} membership is now active.

      Access your member dashboard: ${this.baseUrl}/dashboard

      Welcome to the family!
    `}generateMembershipUpgradeHTML(e){return`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #b45309, #d97706); color: white; padding: 30px; text-align: center; }
            .content { background: #fff; padding: 30px; border: 1px solid #e5e7eb; }
            .upgrade-box { background: #fef3c7; padding: 20px; border-radius: 8px; text-align: center; margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Membership Upgraded!</h1>
              <p>Welcome to ${e.newTier}</p>
            </div>
            <div class="content">
              <p>Dear ${e.userName},</p>

              <div class="upgrade-box">
                <h2>Congratulations on your upgrade!</h2>
                <p>You now have access to exclusive ${e.newTier} benefits</p>
              </div>

              <h3>Your New Benefits:</h3>
              ${this.getMembershipBenefitsHTML(e.newTier)}
            </div>
          </div>
        </body>
      </html>
    `}generateMembershipUpgradeText(e){return`
      MEMBERSHIP UPGRADED - BERENICE LONDON

      Dear ${e.userName},

      Congratulations! Your membership has been upgraded to ${e.newTier}.

      Enjoy your new benefits!
    `}generatePaymentConfirmationHTML(e){return`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #b45309, #d97706); color: white; padding: 30px; text-align: center; }
            .content { background: #fff; padding: 30px; border: 1px solid #e5e7eb; }
            .payment-details { background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Payment Received</h1>
              <p>Thank you for your payment</p>
            </div>
            <div class="content">
              <p>Dear ${e.userName},</p>
              <p>We've successfully processed your payment.</p>

              <div class="payment-details">
                <h3>Payment Details</h3>
                <p><strong>Amount:</strong> \xa3${e.amount}</p>
                <p><strong>Payment ID:</strong> ${e.paymentId}</p>
                <p><strong>Date:</strong> ${e.paymentDate}</p>
                <p><strong>Description:</strong> ${e.description}</p>
              </div>

              <p>You should receive the benefits of your purchase immediately.</p>
            </div>
          </div>
        </body>
      </html>
    `}generatePaymentConfirmationText(e){return`
      PAYMENT RECEIVED - BERENICE LONDON

      Dear ${e.userName},

      We've successfully processed your payment.

      Amount: \xa3${e.amount}
      Payment ID: ${e.paymentId}
      Date: ${e.paymentDate}

      Thank you!
    `}getMembershipBenefitsHTML(e){let t=this.getMembershipBenefits(e);return`<ul>${t.map(e=>`<li>${e}</li>`).join("")}</ul>`}getMembershipBenefits(e){switch(e){case"premium":return["15% discount on all services","Priority booking","Monthly styling tips newsletter","Free product samples"];case"elite":return["25% discount on all services","Priority booking","Monthly styling tips newsletter","Free product samples","1-on-1 styling sessions","Exclusive event invitations"];default:return["Access to member blog","Basic booking system","Community access"]}}async sendEmail(e,t){try{let r=this.getTemplate(e,t);console.log("\uD83D\uDCE7 Email Notification:",{to:t.userEmail,subject:r.subject,type:e,data:t}),await new Promise(e=>setTimeout(e,500));let n=`msg_${Date.now()}_${Math.random().toString(36).substr(2,9)}`;return{success:!0,messageId:n}}catch(e){return console.error("Email sending failed:",e),{success:!1,error:"Failed to send email notification"}}}async sendBookingConfirmation(e){return this.sendEmail("booking_confirmation",e)}async sendBookingReminder(e){return this.sendEmail("booking_reminder",e)}async sendMembershipWelcome(e){return this.sendEmail("membership_welcome",e)}async sendMembershipUpgrade(e){return this.sendEmail("membership_upgrade",e)}async sendPaymentConfirmation(e){return this.sendEmail("payment_confirmation",e)}constructor(){this.baseUrl="https://berenice-london.com"}}let p=new c;var l=r(44999);let u=new Map,m=async e=>{try{console.log(`✅ Payment succeeded: ${e.id}`);let t=Array.from(u.values()).find(t=>t.paymentIntentId===e.id);t?(t.status="paid",t.updatedAt=new Date().toISOString()):t={id:`order_${Date.now()}_${Math.random().toString(36).substr(2,9)}`,paymentIntentId:e.id,customerEmail:e.receipt_email||e.customer?.email||"unknown@example.com",amount:e.amount,currency:e.currency,status:"paid",items:[],shippingAddress:e.shipping,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),metadata:e.metadata||{}},u.set(t.id,t);try{await p.sendEmail("order_confirmation",{userEmail:t.customerEmail,userName:t.shippingAddress?.name||"Valued Customer",orderId:t.id,orderTotal:(t.amount/100).toFixed(2),orderDate:new Date(t.createdAt).toLocaleDateString("en-GB"),items:t.metadata.items||"Items from your order",shippingAddress:t.shippingAddress?`${t.shippingAddress.address.line1}, ${t.shippingAddress.address.city}, ${t.shippingAddress.address.postal_code}`:"Shipping address on file"})}catch(e){console.error("Failed to send confirmation email:",e)}return await f(t),{success:!0,orderId:t.id}}catch(e){throw console.error("Error handling payment succeeded:",e),e}},h=async e=>{try{console.log(`❌ Payment failed: ${e.id}`);let t=Array.from(u.values()).find(t=>t.paymentIntentId===e.id);t&&(t.status="cancelled",t.updatedAt=new Date().toISOString(),u.set(t.id,t));let r=e.receipt_email||e.customer?.email;if(r)try{await p.sendEmail("payment_failed",{userEmail:r,userName:e.shipping?.name||"Valued Customer",paymentIntentId:e.id,amount:(e.amount/100).toFixed(2),currency:e.currency.toUpperCase(),failureReason:e.last_payment_error?.message||"Payment was declined"})}catch(e){console.error("Failed to send payment failure email:",e)}return{success:!0,status:"payment_failed"}}catch(e){throw console.error("Error handling payment failed:",e),e}},g=async e=>{try{console.log(`⚠️ Charge dispute created: ${e.id}`);let t=e.charge,r=t.payment_intent,n=Array.from(u.values()).find(e=>e.paymentIntentId===r);try{await p.sendEmail("admin_notification",{userEmail:"disputes@berenicelondon.co.uk",userName:"Admin Team",subject:`New Dispute: ${e.id}`,message:`A new dispute has been created for order ${n?.id||"unknown"}.

Dispute Details:
- Dispute ID: ${e.id}
- Amount: \xa3${(e.amount/100).toFixed(2)}
- Reason: ${e.reason}
- Status: ${e.status}
- Customer: ${t.billing_details?.email||"unknown"}

Please review this dispute in your Stripe dashboard.`})}catch(e){console.error("Failed to send dispute notification:",e)}return{success:!0,disputeId:e.id}}catch(e){throw console.error("Error handling charge dispute:",e),e}},b=async(e,t)=>{try{console.log(`📅 Subscription event: ${t} - ${e.id}`);let r=e.customer?.email;if(r)try{let n="subscription_updated",i={userEmail:r,subscriptionId:e.id,status:e.status};switch(t){case"customer.subscription.created":n="subscription_welcome",i.planName=e.items.data[0]?.price.nickname||"Premium Plan";break;case"customer.subscription.updated":n="subscription_updated";break;case"customer.subscription.deleted":n="subscription_cancelled"}await p.sendEmail(n,i)}catch(e){console.error("Failed to send subscription email:",e)}return{success:!0,subscriptionId:e.id}}catch(e){throw console.error("Error handling subscription event:",e),e}},y=async(e,t)=>{try{console.log(`🧾 Invoice event: ${t} - ${e.id}`);let r=e.customer_email||e.customer?.email;if(r)try{"invoice.payment_succeeded"===t?await p.sendEmail("invoice_paid",{userEmail:r,userName:e.customer_name||"Valued Customer",invoiceId:e.id,amount:(e.amount_paid/100).toFixed(2),currency:e.currency.toUpperCase(),paidAt:new Date().toLocaleDateString("en-GB")}):"invoice.payment_failed"===t&&await p.sendEmail("invoice_failed",{userEmail:r,userName:e.customer_name||"Valued Customer",invoiceId:e.id,amount:(e.amount_due/100).toFixed(2),currency:e.currency.toUpperCase(),dueDate:new Date(1e3*e.due_date).toLocaleDateString("en-GB")})}catch(e){console.error("Failed to send invoice email:",e)}return{success:!0,invoiceId:e.id}}catch(e){throw console.error("Error handling invoice event:",e),e}},f=async e=>{try{return console.log(`📦 Triggering fulfillment for order: ${e.id}`),setTimeout(async()=>{try{e.status="shipped",e.updatedAt=new Date().toISOString(),u.set(e.id,e),await p.sendEmail("order_shipped",{userEmail:e.customerEmail,userName:e.shippingAddress?.name||"Valued Customer",orderId:e.id,trackingNumber:`BL${Date.now()}`,estimatedDelivery:new Date(Date.now()+2592e5).toLocaleDateString("en-GB")})}catch(e){console.error("Error in fulfillment process:",e)}},5e3),{success:!0}}catch(e){throw console.error("Error triggering fulfillment:",e),e}};async function x(e){let t,r=(0,d.Jh)(),n=(await (0,l.b3)()).get("stripe-signature");if(!n)return console.error("No Stripe signature found"),s.NextResponse.json({error:"No signature"},{status:400});try{let i=await e.text(),o=process.env.STRIPE_WEBHOOK_SECRET||process.env.STRIPE_WEBHOOK_SECRET_LIVE;if(!o)return console.error("Webhook secret not configured"),s.NextResponse.json({error:"Webhook secret not configured"},{status:500});t=r.webhooks.constructEvent(i,n,o)}catch(e){return console.error("Webhook signature verification failed:",e.message),s.NextResponse.json({error:"Invalid signature"},{status:400})}try{console.log(`📨 Received webhook: ${t.type}`);let e={success:!0};switch(t.type){case"payment_intent.succeeded":e=await m(t.data.object);break;case"payment_intent.payment_failed":e=await h(t.data.object);break;case"charge.dispute.created":e=await g(t.data.object);break;case"customer.subscription.created":case"customer.subscription.updated":case"customer.subscription.deleted":e=await b(t.data.object,t.type);break;case"invoice.payment_succeeded":case"invoice.payment_failed":e=await y(t.data.object,t.type);break;default:console.log(`Unhandled webhook event type: ${t.type}`),e={success:!0,message:"Event received but not processed"}}return console.log(`✅ Webhook processed successfully: ${t.type}`),s.NextResponse.json(e)}catch(e){if(console.error(`❌ Error processing webhook ${t.type}:`,e),e.critical)return s.NextResponse.json({error:e.message},{status:500});return s.NextResponse.json({success:!0,warning:"Event received but processing encountered non-critical error",error:e.message})}}async function v(e){return s.NextResponse.json({message:"Stripe webhook endpoint is active",timestamp:new Date().toISOString(),events:d.sF.webhookEvents})}let w=new i.AppRouteRouteModule({definition:{kind:o.RouteKind.APP_ROUTE,page:"/api/stripe/webhook/route",pathname:"/api/stripe/webhook",filename:"route",bundlePath:"app/api/stripe/webhook/route"},resolvedPagePath:"/home/project/berenice-london/src/app/api/stripe/webhook/route.ts",nextConfigOutput:"",userland:n}),{workAsyncStorage:E,workUnitAsyncStorage:k,serverHooks:$}=w;function T(){return(0,a.patchFetch)({workAsyncStorage:E,workUnitAsyncStorage:k})}},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},78335:()=>{},79646:e=>{"use strict";e.exports=require("child_process")},81630:e=>{"use strict";e.exports=require("http")},94735:e=>{"use strict";e.exports=require("events")},96487:()=>{},96706:(e,t,r)=>{"use strict";r.d(t,{Ci:()=>a,Jh:()=>i,sF:()=>o}),r(9365);let n={publishableKey:process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY_LIVE||"",secretKey:process.env.STRIPE_SECRET_KEY_LIVE,webhookSecret:process.env.STRIPE_WEBHOOK_SECRET_LIVE},i=()=>{if(!n.secretKey)throw Error("Stripe secret key is not configured");return new(r(8905))(n.secretKey,{apiVersion:"2023-10-16",typescript:!0})},o={currency:"gbp",paymentMethods:["card","google_pay","apple_pay","link"],shippingCountries:["GB","US","CA","AU","IE","DE","FR","IT","ES","NL"],businessInfo:{name:"Berenice London",description:"Premium Hair Solutions",website:"https://berenicelondon.co.uk",supportEmail:"support@berenicelondon.co.uk",supportPhone:"+44 20 7123 4567"},webhookEvents:["payment_intent.succeeded","payment_intent.payment_failed","charge.dispute.created","customer.subscription.created","customer.subscription.updated","customer.subscription.deleted","invoice.payment_succeeded","invoice.payment_failed"],security:{require3DS:5e3,enableRadar:!0,captureMethod:"automatic"}},a=e=>Math.round(100*e)}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),n=t.X(0,[447,580,7],()=>r(53775));module.exports=n})();