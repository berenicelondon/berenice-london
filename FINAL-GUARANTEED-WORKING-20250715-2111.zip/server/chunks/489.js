"use strict";exports.id=489,exports.ids=[489],exports.modules={13:(e,t,r)=>{r.d(t,{J:()=>d});var a=r(6392),o=r(3210),n=r(8148),i=r(4224),s=r(4780);let l=(0,i.F)("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"),d=o.forwardRef(({className:e,...t},r)=>(0,a.jsx)(n.b,{ref:r,className:(0,s.cn)(l(),e),...t}));d.displayName=n.b.displayName},2477:(e,t,r)=>{r.d(t,{A:()=>a});let a=(0,r(2614).A)("Copy",[["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]])},2720:(e,t,r)=>{r.d(t,{eu:()=>C,q5:()=>T,BK:()=>E});var a=r(6392),o=r(3210),n=r(1273),i=r(3495),s=r(6156),l=r(4163),d=r(7379);function c(){return()=>{}}var u=r(687),h="Avatar",[m,p]=(0,n.A)(h),[f,g]=m(h),y=o.forwardRef((e,t)=>{let{__scopeAvatar:r,...a}=e,[n,i]=o.useState("idle");return(0,u.jsx)(f,{scope:r,imageLoadingStatus:n,onImageLoadingStatusChange:i,children:(0,u.jsx)(l.sG.span,{...a,ref:t})})});y.displayName=h;var w="AvatarImage",v=o.forwardRef((e,t)=>{let{__scopeAvatar:r,src:a,onLoadingStatusChange:n=()=>{},...h}=e,m=g(w,r),p=function(e,{referrerPolicy:t,crossOrigin:r}){let a=(0,d.useSyncExternalStore)(c,()=>!0,()=>!1),n=o.useRef(null),i=a?(n.current||(n.current=new window.Image),n.current):null,[l,u]=o.useState(()=>k(i,e));return(0,s.N)(()=>{u(k(i,e))},[i,e]),(0,s.N)(()=>{let e=e=>()=>{u(e)};if(!i)return;let a=e("loaded"),o=e("error");return i.addEventListener("load",a),i.addEventListener("error",o),t&&(i.referrerPolicy=t),"string"==typeof r&&(i.crossOrigin=r),()=>{i.removeEventListener("load",a),i.removeEventListener("error",o)}},[i,r,t]),l}(a,h),f=(0,i.c)(e=>{n(e),m.onImageLoadingStatusChange(e)});return(0,s.N)(()=>{"idle"!==p&&f(p)},[p,f]),"loaded"===p?(0,u.jsx)(l.sG.img,{...h,ref:t,src:a}):null});v.displayName=w;var b="AvatarFallback",x=o.forwardRef((e,t)=>{let{__scopeAvatar:r,delayMs:a,...n}=e,i=g(b,r),[s,d]=o.useState(void 0===a);return o.useEffect(()=>{if(void 0!==a){let e=window.setTimeout(()=>d(!0),a);return()=>window.clearTimeout(e)}},[a]),s&&"loaded"!==i.imageLoadingStatus?(0,u.jsx)(l.sG.span,{...n,ref:t}):null});function k(e,t){return e?t?(e.src!==t&&(e.src=t),e.complete&&e.naturalWidth>0?"loaded":"loading"):"error":"idle"}x.displayName=b;var S=r(4780);let C=o.forwardRef(({className:e,...t},r)=>(0,a.jsx)(y,{ref:r,className:(0,S.cn)("relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full",e),...t}));C.displayName=y.displayName;let E=o.forwardRef(({className:e,...t},r)=>(0,a.jsx)(v,{ref:r,className:(0,S.cn)("aspect-square h-full w-full",e),...t}));E.displayName=v.displayName;let T=o.forwardRef(({className:e,...t},r)=>(0,a.jsx)(x,{ref:r,className:(0,S.cn)("flex h-full w-full items-center justify-center rounded-full bg-muted",e),...t}));T.displayName=x.displayName},3332:(e,t,r)=>{var a=r(3210),o="function"==typeof Object.is?Object.is:function(e,t){return e===t&&(0!==e||1/e==1/t)||e!=e&&t!=t},n=a.useState,i=a.useEffect,s=a.useLayoutEffect,l=a.useDebugValue;function d(e){var t=e.getSnapshot;e=e.value;try{var r=t();return!o(e,r)}catch(e){return!0}}var c="undefined"==typeof window||void 0===window.document||void 0===window.document.createElement?function(e,t){return t()}:function(e,t){var r=t(),a=n({inst:{value:r,getSnapshot:t}}),o=a[0].inst,c=a[1];return s(function(){o.value=r,o.getSnapshot=t,d(o)&&c({inst:o})},[e,r,t]),i(function(){return d(o)&&c({inst:o}),e(function(){d(o)&&c({inst:o})})},[e]),l(r),r};t.useSyncExternalStore=void 0!==a.useSyncExternalStore?a.useSyncExternalStore:c},4008:(e,t,r)=>{r.d(t,{A:()=>o,t:()=>a});let a=[{id:"membership",name:"Membership",description:"Updates and benefits for our member community"},{id:"bespoke-wigs",name:"Bespoke Wigs & Toppers",description:"Custom-made hairpiece insights and stories"},{id:"ready-made",name:"Ready-Made Collection",description:"Our curated selection of premium wigs and toppers"},{id:"education",name:"Education & Training",description:"Professional courses and learning resources"},{id:"care-tips",name:"Care & Maintenance",description:"Expert tips for maintaining your hairpieces"},{id:"styling",name:"Styling Guide",description:"Creative styling ideas and techniques"}],o=[{id:"1",title:"The Ultimate Guide to Measuring Your Head for a Perfect Wig Fit",excerpt:"Learn the professional techniques our experts use to ensure your custom wig fits perfectly every time.",content:`Getting the perfect fit for your wig starts with accurate measurements. In this comprehensive guide, we'll walk you through the exact process our master craftspeople use at Berenice London.

## Why Accurate Measurements Matter

A properly fitted wig not only looks more natural but also feels more comfortable and secure. Poor measurements can lead to slipping, discomfort, or an unnatural appearance.

## Essential Tools You'll Need

- A flexible measuring tape
- A mirror
- A pen and paper
- A friend to help (optional but recommended)

## Step-by-Step Measurement Process

### 1. Circumference Measurement
Place the measuring tape around your head, about 1/8 inch above your ears and across your forehead. This gives you the overall head circumference.

### 2. Front to Back Measurement
Measure from your natural hairline at the forehead to the nape of your neck, going over the crown of your head.

### 3. Ear to Ear Measurement
Measure from the top of one ear, over the crown, to the top of the other ear.

### 4. Temple to Temple
Measure across your forehead from temple to temple, about 1 inch above your eyebrows.

## Tips for Accuracy

- Take measurements when your hair is flat against your head
- Don't pull the tape too tight or too loose
- Take each measurement twice to ensure accuracy
- Have someone help you for the most precise results

## What to Do With Your Measurements

Once you have all your measurements, our team will use these to create your custom pattern. We'll also discuss your lifestyle, styling preferences, and any specific needs you might have.

Remember, at Berenice London, we're here to guide you through every step of the process. Book a consultation with our experts to ensure your measurements are perfect and discuss your custom wig options.`,category:"education",author:"Sarah Mitchell",publishDate:"2024-01-15",readTime:5,tags:["measurements","fitting","custom-wigs","how-to"],featured:!0,imageUrl:"https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=800&h=400&fit=crop"},{id:"2",title:"Washing Your Hairpiece: A Complete Care Guide",excerpt:"Proper washing techniques to maintain the beauty and longevity of your premium hairpiece.",content:`Your hairpiece is an investment in your confidence and appearance. Proper care, especially washing, is essential to maintain its beauty and extend its lifespan.

## How Often to Wash

The frequency of washing depends on several factors:
- How often you wear your hairpiece
- Your lifestyle and activities
- Environmental factors
- Hair type (synthetic vs. human hair)

Generally, wash your hairpiece every 6-8 wears for human hair pieces, and every 10-12 wears for synthetic ones.

## What You'll Need

- Specialized wig shampoo (never use regular hair shampoo)
- Wig conditioner
- A wide-tooth comb
- A wig stand or mannequin head
- Clean towels
- Cool water

## Step-by-Step Washing Process

### Preparation
1. Gently brush your hairpiece to remove tangles
2. Fill a basin with cool water
3. Add a small amount of wig shampoo

### Washing
1. Immerse the hairpiece in the water
2. Gently swish for 2-3 minutes
3. Don't rub or scrub the hair
4. Rinse thoroughly with cool water

### Conditioning
1. Apply wig conditioner from mid-length to ends
2. Leave for 2-3 minutes
3. Rinse thoroughly

### Drying
1. Gently squeeze out excess water (don't wring)
2. Pat dry with a clean towel
3. Place on a wig stand to air dry
4. Never use heat unless the piece is specifically designed for it

## Pro Tips

- Always wash in cool water to prevent damage
- Use products specifically designed for wigs
- Be gentle throughout the process
- Store properly when not in use

Following these steps will help ensure your Berenice London hairpiece maintains its premium quality and appearance for years to come.`,category:"care-tips",author:"Emma Thompson",publishDate:"2024-01-10",readTime:4,tags:["hair-care","washing","maintenance","hairpiece"],featured:!0,imageUrl:"https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=800&h=400&fit=crop"},{id:"3",title:"New Premium Membership Benefits: What You Need to Know",excerpt:"Discover the exciting new benefits we've added to our Premium and Elite membership tiers.",content:`We're thrilled to announce exciting new benefits for our Premium and Elite members, effective immediately. These enhancements reflect our commitment to providing exceptional value and service to our community.

## New Premium Membership Benefits

### Monthly Styling Consultations
Premium members now receive monthly virtual styling consultations with our expert team. Perfect for seasonal updates or special occasion styling.

### Exclusive Product Access
Get early access to new arrivals and limited-edition pieces before they're available to the general public.

### Enhanced Discount Structure
- 15% off all services (increased from 10%)
- 20% off ready-made collection
- Free shipping on all orders

## Elite Membership Enhancements

### Personal Stylist Assignment
Each Elite member now gets a dedicated personal stylist for ongoing support and customized recommendations.

### Quarterly In-Person Sessions
Enjoy quarterly in-person styling and maintenance sessions at our London studio.

### VIP Event Access
Exclusive invitations to styling workshops, fashion shows, and member-only events.

## How to Upgrade

Current Basic members can upgrade to Premium or Elite at any time through their member dashboard. Contact our team for personalized upgrade recommendations based on your needs.

## Coming Soon

We're also working on:
- Mobile app for easier booking and communication
- Virtual reality wig try-on technology
- Expanded educational content library

Thank you for being part of the Berenice London community. Your membership makes all these improvements possible.`,category:"membership",author:"Berenice London Team",publishDate:"2024-01-08",readTime:3,tags:["membership","benefits","premium","elite"],featured:!1},{id:"4",title:"The Art of Bespoke Wig Creation: Behind the Scenes",excerpt:"Take a journey into our workshop and discover the meticulous craftsmanship behind every custom piece.",content:`Creating a bespoke wig is both an art and a science. Each piece that leaves our London workshop represents hundreds of hours of skilled craftsmanship and attention to detail.

## The Design Process

Every bespoke piece begins with a comprehensive consultation. We discuss:
- Your lifestyle and daily routine
- Color preferences and skin tone
- Desired length and style
- Specific requirements or concerns

## Hair Selection

We source only the finest materials:
- Premium European hair for the most natural look
- Ethically sourced materials
- Multiple color matching for perfect blends
- Quality testing for durability and appearance

## The Crafting Process

### Foundation Creation
The wig cap is hand-crafted to your exact measurements, ensuring a perfect fit that's both comfortable and secure.

### Hair Insertion
Each hair is individually hand-tied using traditional techniques passed down through generations of master craftspeople.

### Styling and Finishing
The final styling brings your vision to life, with attention to natural growth patterns and movement.

## Quality Assurance

Before delivery, every piece undergoes rigorous quality checks:
- Fit verification
- Color accuracy
- Movement and naturalness
- Durability testing

## The Result

The result is a truly unique piece that not only meets but exceeds your expectations. A bespoke wig from Berenice London isn't just a hairpiece—it's a transformation that restores confidence and enhances your natural beauty.

Ready to begin your bespoke journey? Book a consultation with our master craftspeople today.`,category:"bespoke-wigs",author:"Master Craftsman James Wilson",publishDate:"2024-01-05",readTime:6,tags:["bespoke","craftsmanship","custom-wigs","process"],featured:!0,imageUrl:"https://images.unsplash.com/photo-1562322140-8baeececf3df?w=800&h=400&fit=crop"},{id:"5",title:"Spring 2024 Ready-Made Collection Preview",excerpt:"Get an exclusive first look at our stunning new ready-made pieces for the upcoming season.",content:`Spring brings new beginnings, and our Spring 2024 Ready-Made Collection embodies fresh sophistication and effortless elegance.

## Collection Highlights

### Natural Textures
This season emphasizes natural movement and texture, with pieces that complement rather than mask your natural beauty.

### Color Palette
- Warm honey blondes
- Rich chocolate browns
- Sophisticated salt-and-pepper grays
- Bold copper reds for the adventurous

### Trending Styles

#### The "London Bob"
A chic, shoulder-length cut with subtle layers that works for any occasion.

#### "Garden Party Waves"
Romantic, flowing waves perfect for spring and summer events.

#### "Executive Elegance"
Professional styles that command respect in any boardroom.

## Technical Innovations

### Improved Cap Construction
Our new cap design offers:
- Better breathability for warmer weather
- Enhanced comfort for all-day wear
- More secure fit with adjustable sizing

### Advanced Hair Processing
New treatment methods ensure:
- Longer-lasting color
- Improved texture retention
- Enhanced shine and movement

## Availability

The collection launches February 15th, with Premium and Elite members getting early access starting February 1st.

Each piece comes with:
- Professional styling guide
- Care instruction kit
- 6-month warranty
- Complimentary initial styling session

Visit our showroom or book a virtual consultation to see these beautiful pieces and find your perfect match for spring.`,category:"ready-made",author:"Design Team Lead Maria Rodriguez",publishDate:"2024-01-03",readTime:4,tags:["spring-2024","ready-made","collection","new-arrivals"],featured:!1,imageUrl:"https://images.unsplash.com/photo-1594736797933-d0e501ba2fe0?w=800&h=400&fit=crop"},{id:"6",title:"5 Essential Styling Tools Every Wig Owner Should Have",excerpt:"Build your styling toolkit with these professional-grade tools recommended by our expert stylists.",content:`The right tools make all the difference in maintaining and styling your wig. Here are the five essential items every wig owner should have in their toolkit.

## 1. Wide-Tooth Comb

### Why You Need It
A wide-tooth comb is gentle on wig fibers and prevents unnecessary tension that can cause shedding or damage.

### How to Use
- Always start combing from the ends
- Work your way up to the roots gradually
- Use gentle, downward motions

### Our Recommendation
Look for combs made from seamless materials to prevent snagging.

## 2. Wig Brush with Ball-Tipped Bristles

### Benefits
- Reduces static and flyaways
- Distributes natural oils evenly
- Gentle on both synthetic and human hair

### Best Practices
- Brush when the wig is dry
- Use long, smooth strokes
- Clean your brush regularly

## 3. Wig Stand or Mannequin Head

### Essential for
- Proper storage between wears
- Styling and maintenance
- Air drying after washing

### Storage Tips
- Choose a stand that matches your head size
- Store in a cool, dry place
- Cover with a silk scarf to prevent dust

## 4. Heat Protectant Spray

### When to Use
Before any heat styling on human hair wigs (never use heat on synthetic unless specifically designed for it).

### Protection Benefits
- Prevents heat damage
- Maintains hair integrity
- Extends wig lifespan

## 5. Specialized Wig Shampoo and Conditioner

### Why Regular Products Don't Work
Regular hair products can:
- Strip color from wig fibers
- Build up on the cap
- Reduce the wig's lifespan

### Choosing the Right Products
- Look for sulfate-free formulas
- Choose products designed for your wig type
- Consider professional-grade options

## Bonus Tool: Silk Scarf

### Multiple Uses
- Sleeping protection
- Storage covering
- Gentle drying aid

## Investment in Longevity

Quality tools are an investment in your wig's longevity and appearance. At Berenice London, we offer a complete styling toolkit designed specifically for our pieces.

Ready to upgrade your wig care routine? Contact our team for personalized tool recommendations based on your specific needs and wig type.`,category:"styling",author:"Senior Stylist Rachel Green",publishDate:"2023-12-28",readTime:5,tags:["styling-tools","wig-care","maintenance","professional-tips"],featured:!1}]},4493:(e,t,r)=>{r.d(t,{BT:()=>d,Wu:()=>c,ZB:()=>l,Zp:()=>i,aR:()=>s});var a=r(6392),o=r(3210),n=r(4780);let i=o.forwardRef(({className:e,...t},r)=>(0,a.jsx)("div",{ref:r,className:(0,n.cn)("rounded-xl border bg-card text-card-foreground shadow",e),...t}));i.displayName="Card";let s=o.forwardRef(({className:e,...t},r)=>(0,a.jsx)("div",{ref:r,className:(0,n.cn)("flex flex-col space-y-1.5 p-6",e),...t}));s.displayName="CardHeader";let l=o.forwardRef(({className:e,...t},r)=>(0,a.jsx)("div",{ref:r,className:(0,n.cn)("font-semibold leading-none tracking-tight",e),...t}));l.displayName="CardTitle";let d=o.forwardRef(({className:e,...t},r)=>(0,a.jsx)("div",{ref:r,className:(0,n.cn)("text-sm text-muted-foreground",e),...t}));d.displayName="CardDescription";let c=o.forwardRef(({className:e,...t},r)=>(0,a.jsx)("div",{ref:r,className:(0,n.cn)("p-6 pt-0",e),...t}));c.displayName="CardContent",o.forwardRef(({className:e,...t},r)=>(0,a.jsx)("div",{ref:r,className:(0,n.cn)("flex items-center p-6 pt-0",e),...t})).displayName="CardFooter"},4780:(e,t,r)=>{r.d(t,{cn:()=>n});var a=r(9384),o=r(2348);function n(...e){return(0,o.QP)((0,a.$)(e))}},5036:(e,t,r)=>{r.d(t,{A:()=>a});let a=(0,r(2614).A)("Clock",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]])},6622:(e,t,r)=>{r.d(t,{A:()=>a});let a=(0,r(2614).A)("Calendar",[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}]])},6834:(e,t,r)=>{r.d(t,{E:()=>s});var a=r(6392);r(3210);var o=r(4224),n=r(4780);let i=(0,o.F)("inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",{variants:{variant:{default:"border-transparent bg-primary text-primary-foreground shadow hover:bg-primary/80",secondary:"border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",destructive:"border-transparent bg-destructive text-destructive-foreground shadow hover:bg-destructive/80",outline:"text-foreground"}},defaultVariants:{variant:"default"}});function s({className:e,variant:t,...r}){return(0,a.jsx)("div",{className:(0,n.cn)(i({variant:t}),e),...r})}},7034:(e,t,r)=>{r.d(t,{A:()=>a});let a=(0,r(2614).A)("BookOpen",[["path",{d:"M12 7v14",key:"1akyts"}],["path",{d:"M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z",key:"ruj8y"}]])},7379:(e,t,r)=>{e.exports=r(3332)},8148:(e,t,r)=>{r.d(t,{b:()=>s});var a=r(3210),o=r(4163),n=r(687),i=a.forwardRef((e,t)=>(0,n.jsx)(o.sG.label,{...e,ref:t,onMouseDown:t=>{t.target.closest("button, input, select, textarea")||(e.onMouseDown?.(t),!t.defaultPrevented&&t.detail>1&&t.preventDefault())}}));i.displayName="Label";var s=i},9523:(e,t,r)=>{r.d(t,{$:()=>d,r:()=>l});var a=r(6392),o=r(3210),n=r(8730),i=r(4224),s=r(4780);let l=(0,i.F)("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",{variants:{variant:{default:"bg-primary text-primary-foreground shadow hover:bg-primary/90",destructive:"bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",outline:"border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",secondary:"bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",ghost:"hover:bg-accent hover:text-accent-foreground",link:"text-primary underline-offset-4 hover:underline"},size:{default:"h-9 px-4 py-2",sm:"h-8 rounded-md px-3 text-xs",lg:"h-10 rounded-md px-8",icon:"h-9 w-9"}},defaultVariants:{variant:"default",size:"default"}}),d=o.forwardRef(({className:e,variant:t,size:r,asChild:o=!1,...i},d)=>{let c=o?n.DX:"button";return(0,a.jsx)(c,{className:(0,s.cn)(l({variant:t,size:r,className:e})),ref:d,...i})});d.displayName="Button"},9667:(e,t,r)=>{r.d(t,{p:()=>i});var a=r(6392),o=r(3210),n=r(4780);let i=o.forwardRef(({className:e,type:t,...r},o)=>(0,a.jsx)("input",{type:t,className:(0,n.cn)("flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-base shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",e),ref:o,...r}));i.displayName="Input"}};